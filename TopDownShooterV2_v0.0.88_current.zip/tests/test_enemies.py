"""Tests for static enemy marker spawning."""

from topdown_shooter.combat.enemies import EnemySystem
from topdown_shooter.combat.projectiles import ProjectileState
from topdown_shooter.world.coordinates import TileCoord, WorldCoord, world_to_tile
from topdown_shooter.world.runtime_map import RuntimeMap, TacticalRuntimeSummary
from topdown_shooter.world.tile import RuntimeTile


def _build_runtime_map() -> RuntimeMap:
    """Build a small runtime map for enemy marker tests."""
    tiles = tuple(
        tuple(RuntimeTile(symbol="+", walkable=True, movement_cost=1) for _x in range(4))
        for _y in range(3)
    )
    return RuntimeMap(
        width_tiles=4,
        height_tiles=3,
        tile_size_px=16,
        tiles=tiles,
        start_tile=TileCoord(0, 0),
        goal_tile=TileCoord(3, 2),
        tactical_summary=TacticalRuntimeSummary(
            combat_zones=0,
            cover_points=0,
            choke_points=0,
            flank_routes=0,
            enemy_spawn_zones=2,
            fallback_positions=0,
        ),
    )


def test_enemy_system_spawns_markers_from_tactical_spawn_zones() -> None:
    """Enemy system should create one static marker per valid tactical spawn."""
    tactical_map: dict[str, object] = {
        "enemy_spawn_zones": [
            {
                "id": "spawn_0",
                "zone_id": "zone_a",
                "spawn_type": "initial_squad",
                "position": [1, 2],
                "preferred_roles": ["rifleman", "flanker"],
            },
            {
                "id": "spawn_1",
                "zone_id": "zone_b",
                "spawn_type": "ambush_squad",
                "position": [3, 0],
                "preferred_roles": ["scout"],
            },
        ],
    }

    system = EnemySystem.from_tactical_map(tactical_map, _build_runtime_map())

    assert system.stats.active_enemies == 2
    assert system.stats.spawned_enemies == 2
    assert system.stats.source_spawn_zones == 2
    first_enemy = system.enemies[0]
    assert first_enemy.enemy_id == "enemy_0"
    assert first_enemy.spawn_id == "spawn_0"
    assert first_enemy.zone_id == "zone_a"
    assert first_enemy.spawn_type == "initial_squad"
    assert first_enemy.role == "rifleman"
    assert first_enemy.tile == TileCoord(x=1, y=2)
    assert first_enemy.world_position == WorldCoord(x=24.0, y=40.0)


def test_enemy_system_skips_invalid_or_out_of_bounds_spawns() -> None:
    """Enemy system should skip unusable tactical spawn entries."""
    tactical_map: dict[str, object] = {
        "enemy_spawn_zones": [
            {"id": "bad_format", "position": [1]},
            {"id": "bad_type", "position": [True, 1]},
            {"id": "out_of_bounds", "position": [99, 1]},
            {"id": "valid", "position": [2, 1]},
        ],
    }

    system = EnemySystem.from_tactical_map(tactical_map, _build_runtime_map())

    assert system.stats.source_spawn_zones == 4
    assert system.stats.active_enemies == 1
    assert system.enemies[0].spawn_id == "valid"
    assert system.enemies[0].tile == TileCoord(x=2, y=1)


def test_enemy_system_applies_projectile_damage_and_hit_markers() -> None:
    """Enemy system should damage enemies and consume hitting projectiles."""
    tactical_map: dict[str, object] = {
        "enemy_spawn_zones": [
            {
                "id": "spawn_0",
                "zone_id": "zone_a",
                "spawn_type": "initial_squad",
                "position": [2, 1],
                "preferred_roles": ["rifleman"],
            },
        ],
    }
    system = EnemySystem.from_tactical_map(
        tactical_map,
        _build_runtime_map(),
        enemy_max_health=50.0,
        hit_marker_lifetime_seconds=0.2,
        hit_marker_radius_px=7.0,
    )
    projectile = ProjectileState(
        position=WorldCoord(x=48.0, y=24.0),
        previous_position=WorldCoord(x=24.0, y=24.0),
        direction_x=1.0,
        direction_y=0.0,
        speed_px_per_second=16.0,
        max_distance_px=64.0,
        lifetime_seconds=10.0,
        radius_px=3.0,
        damage=35.0,
    )

    system.apply_projectile_hits((projectile,), enemy_collision_radius_px=6.0)

    assert projectile.alive is False
    assert system.stats.active_enemies == 1
    assert system.stats.total_hits == 1
    assert system.stats.killed_enemies == 0
    assert system.stats.active_hit_markers == 1
    assert system.enemies[0].health == 15.0
    assert system.enemies[0].last_hit_age_seconds == 0.0
    assert system.hit_markers[0].radius_px == 7.0

    system.update(frame_time=0.1)

    assert system.enemies[0].last_hit_age_seconds == 0.1
    assert system.stats.active_hit_markers == 1

    system.update(frame_time=0.1)

    assert system.stats.active_hit_markers == 0


def test_enemy_system_removes_enemy_when_health_reaches_zero() -> None:
    """Enemy system should remove enemies killed by projectile damage."""
    tactical_map: dict[str, object] = {
        "enemy_spawn_zones": [
            {
                "id": "spawn_0",
                "zone_id": "zone_a",
                "spawn_type": "initial_squad",
                "position": [2, 1],
                "preferred_roles": ["rifleman"],
            },
        ],
    }
    system = EnemySystem.from_tactical_map(tactical_map, _build_runtime_map(), enemy_max_health=50.0)
    projectile = ProjectileState(
        position=WorldCoord(x=48.0, y=24.0),
        previous_position=WorldCoord(x=24.0, y=24.0),
        direction_x=1.0,
        direction_y=0.0,
        speed_px_per_second=16.0,
        max_distance_px=64.0,
        lifetime_seconds=10.0,
        radius_px=3.0,
        damage=50.0,
    )

    system.apply_projectile_hits((projectile,), enemy_collision_radius_px=6.0)

    assert projectile.alive is False
    assert system.stats.active_enemies == 0
    assert system.stats.spawned_enemies == 1
    assert system.stats.killed_enemies == 1
    assert system.stats.total_hits == 1


def _build_runtime_map_from_rows(rows: tuple[str, ...]) -> RuntimeMap:
    """Build a runtime map from compact walkability rows."""
    tiles = tuple(
        tuple(
            RuntimeTile(symbol=symbol, walkable=symbol != "#", movement_cost=1)
            for symbol in row
        )
        for row in rows
    )
    return RuntimeMap(
        width_tiles=len(rows[0]),
        height_tiles=len(rows),
        tile_size_px=16,
        tiles=tiles,
        start_tile=TileCoord(0, 0),
        goal_tile=TileCoord(len(rows[0]) - 1, len(rows) - 1),
        tactical_summary=TacticalRuntimeSummary(
            combat_zones=0,
            cover_points=0,
            choke_points=0,
            flank_routes=0,
            enemy_spawn_zones=1,
            fallback_positions=0,
        ),
    )




def test_enemy_system_chooses_open_initial_facing_when_spawn_has_no_angle() -> None:
    """Enemy system should face open space instead of a nearby wall."""
    runtime_map = _build_runtime_map_from_rows(("#####", "#++++", "#####"))
    system = EnemySystem.from_tactical_map(
        {
            "enemy_spawn_zones": [
                {
                    "id": "spawn_0",
                    "position": [1, 1],
                },
            ],
        },
        runtime_map,
        smart_facing_enabled=True,
        facing_candidate_step_degrees=90.0,
        facing_probe_side_angle_degrees=0.0,
        facing_wall_penalty_distance_px=16.0,
        facing_probe_step_px=4.0,
    )

    assert system.enemies[0].facing_angle_degrees == 0.0


def test_enemy_system_preserves_explicit_tactical_facing_angle() -> None:
    """Enemy system should keep map-authored facing angles when present."""
    runtime_map = _build_runtime_map_from_rows(("#####", "#++++", "#####"))
    system = EnemySystem.from_tactical_map(
        {
            "enemy_spawn_zones": [
                {
                    "id": "spawn_0",
                    "position": [1, 1],
                    "facing_angle_degrees": 180.0,
                },
            ],
        },
        runtime_map,
        smart_facing_enabled=True,
        facing_candidate_step_degrees=90.0,
        facing_probe_side_angle_degrees=0.0,
        facing_wall_penalty_distance_px=16.0,
        facing_probe_step_px=4.0,
    )

    assert system.enemies[0].facing_angle_degrees == 180.0


def test_enemy_system_alerts_enemy_when_player_is_inside_view_cone() -> None:
    """Enemy perception should alert enemies that see the player."""
    from topdown_shooter.world.collision import TileCollisionService

    runtime_map = _build_runtime_map_from_rows(("++++", "++++", "++++"))
    system = EnemySystem.from_tactical_map(
        {
            "enemy_spawn_zones": [
                {
                    "id": "spawn_0",
                    "position": [1, 1],
                    "facing_angle_degrees": 0.0,
                },
            ],
        },
        runtime_map,
    )

    system.update_perception(
        player_position=WorldCoord(x=48.0, y=24.0),
        collision_service=TileCollisionService(runtime_map),
        vision_range_px=64.0,
        vision_angle_degrees=80.0,
        line_of_sight_sample_step_px=4.0,
    )

    assert system.enemies[0].alerted is True
    assert system.stats.alerted_enemies == 1


def test_enemy_system_keeps_enemy_idle_when_player_is_outside_view_cone() -> None:
    """Enemy perception should ignore players outside the facing cone."""
    from topdown_shooter.world.collision import TileCollisionService

    runtime_map = _build_runtime_map_from_rows(("++++", "++++", "++++"))
    system = EnemySystem.from_tactical_map(
        {
            "enemy_spawn_zones": [
                {
                    "id": "spawn_0",
                    "position": [1, 1],
                    "facing_angle_degrees": 0.0,
                },
            ],
        },
        runtime_map,
    )

    system.update_perception(
        player_position=WorldCoord(x=24.0, y=56.0),
        collision_service=TileCollisionService(runtime_map),
        vision_range_px=64.0,
        vision_angle_degrees=80.0,
        line_of_sight_sample_step_px=4.0,
    )

    assert system.enemies[0].alerted is False
    assert system.stats.alerted_enemies == 0


def test_enemy_system_requires_line_of_sight_for_vision_alert() -> None:
    """Enemy perception should not see through blocked tiles."""
    from topdown_shooter.world.collision import TileCollisionService

    runtime_map = _build_runtime_map_from_rows(("++++", "+#++", "++++"))
    system = EnemySystem.from_tactical_map(
        {
            "enemy_spawn_zones": [
                {
                    "id": "spawn_0",
                    "position": [0, 1],
                    "facing_angle_degrees": 0.0,
                },
            ],
        },
        runtime_map,
    )

    system.update_perception(
        player_position=WorldCoord(x=56.0, y=24.0),
        collision_service=TileCollisionService(runtime_map),
        vision_range_px=96.0,
        vision_angle_degrees=80.0,
        line_of_sight_sample_step_px=4.0,
    )

    assert system.enemies[0].alerted is False


def test_enemy_system_alerts_enemy_when_projectile_hits() -> None:
    """Projectile hits should alert enemies even outside the view cone."""
    tactical_map: dict[str, object] = {
        "enemy_spawn_zones": [
            {
                "id": "spawn_0",
                "position": [2, 1],
                "facing_angle_degrees": 180.0,
            },
        ],
    }
    system = EnemySystem.from_tactical_map(tactical_map, _build_runtime_map(), enemy_max_health=50.0)
    projectile = ProjectileState(
        position=WorldCoord(x=48.0, y=24.0),
        previous_position=WorldCoord(x=24.0, y=24.0),
        direction_x=1.0,
        direction_y=0.0,
        speed_px_per_second=16.0,
        max_distance_px=64.0,
        lifetime_seconds=10.0,
        radius_px=3.0,
        damage=10.0,
    )

    system.apply_projectile_hits((projectile,), enemy_collision_radius_px=6.0)

    assert system.enemies[0].alerted is True
    assert system.stats.alerted_enemies == 1


def test_enemy_system_spawns_squad_members_around_spawn_anchor() -> None:
    """Enemy system should expand one spawn zone into a local squad."""
    runtime_map = _build_runtime_map_from_rows(("++++++++", "++++++++", "++++++++", "++++++++"))
    tactical_map: dict[str, object] = {
        "enemy_spawn_zones": [
            {
                "id": "spawn_0",
                "position": [3, 1],
                "facing_angle_degrees": 0.0,
            },
        ],
    }

    system = EnemySystem.from_tactical_map(
        tactical_map,
        runtime_map,
        min_squad_size=3,
        max_squad_size=3,
        squad_radius_px=32.0,
        min_enemy_spacing_px=8.0,
        max_initial_enemies=10,
        placement_attempts_per_enemy=24,
        spawn_collision_radius_px=2.0,
    )

    assert system.stats.source_spawn_zones == 1
    assert system.stats.spawned_squads == 1
    assert system.stats.spawned_enemies == 3
    assert system.stats.active_enemies == 3
    assert {enemy.spawn_id for enemy in system.enemies} == {"spawn_0"}
    assert len({enemy.world_position for enemy in system.enemies}) == 3


def test_enemy_system_respects_global_initial_enemy_cap() -> None:
    """Enemy system should cap initial enemies across all spawn zones."""
    runtime_map = _build_runtime_map_from_rows(("++++++++", "++++++++", "++++++++", "++++++++"))
    tactical_map: dict[str, object] = {
        "enemy_spawn_zones": [
            {"id": "spawn_0", "position": [2, 1]},
            {"id": "spawn_1", "position": [5, 1]},
        ],
    }

    system = EnemySystem.from_tactical_map(
        tactical_map,
        runtime_map,
        min_squad_size=3,
        max_squad_size=3,
        squad_radius_px=24.0,
        min_enemy_spacing_px=4.0,
        max_initial_enemies=4,
        placement_attempts_per_enemy=24,
        spawn_collision_radius_px=2.0,
    )

    assert system.stats.active_enemies == 4
    assert system.stats.spawned_enemies == 4


def test_alerted_enemy_chases_player_on_walkable_tiles() -> None:
    """Alerted enemies should move toward the player and face the target."""
    from topdown_shooter.world.collision import TileCollisionService

    runtime_map = _build_runtime_map_from_rows(("++++", "++++", "++++"))
    system = EnemySystem.from_tactical_map(
        {
            "enemy_spawn_zones": [
                {
                    "id": "spawn_0",
                    "position": [1, 1],
                    "facing_angle_degrees": 0.0,
                },
            ],
        },
        runtime_map,
    )
    system.enemies[0].alerted = True

    system.update_chase_movement(
        player_position=WorldCoord(x=56.0, y=24.0),
        collision_service=TileCollisionService(runtime_map),
        frame_time=0.5,
        chase_speed_px_per_second=16.0,
        enemy_collision_radius_px=2.0,
        tile_size_px=runtime_map.tile_size_px,
    )

    assert system.enemies[0].world_position == WorldCoord(x=32.0, y=24.0)
    assert system.enemies[0].tile == TileCoord(x=2, y=1)
    assert system.enemies[0].facing_angle_degrees == 0.0
    assert system.stats.moving_enemies == 1


def test_unalerted_enemy_does_not_chase_player() -> None:
    """Unalerted enemies should remain stationary before detection."""
    from topdown_shooter.world.collision import TileCollisionService

    runtime_map = _build_runtime_map_from_rows(("++++", "++++", "++++"))
    system = EnemySystem.from_tactical_map(
        {"enemy_spawn_zones": [{"id": "spawn_0", "position": [1, 1]}]},
        runtime_map,
    )
    initial_position = system.enemies[0].world_position

    system.update_chase_movement(
        player_position=WorldCoord(x=56.0, y=24.0),
        collision_service=TileCollisionService(runtime_map),
        frame_time=0.5,
        chase_speed_px_per_second=16.0,
        enemy_collision_radius_px=2.0,
        tile_size_px=runtime_map.tile_size_px,
    )

    assert system.enemies[0].world_position == initial_position
    assert system.stats.moving_enemies == 0


def test_alerted_enemy_chase_respects_blocked_tiles() -> None:
    """Alerted enemy chase movement should not cross blocked tiles."""
    from topdown_shooter.world.collision import TileCollisionService

    runtime_map = _build_runtime_map_from_rows(("++++", "+#+", "++++"))
    system = EnemySystem.from_tactical_map(
        {
            "enemy_spawn_zones": [
                {
                    "id": "spawn_0",
                    "position": [0, 1],
                    "facing_angle_degrees": 0.0,
                },
            ],
        },
        runtime_map,
    )
    system.enemies[0].alerted = True
    initial_position = system.enemies[0].world_position

    system.update_chase_movement(
        player_position=WorldCoord(x=56.0, y=24.0),
        collision_service=TileCollisionService(runtime_map),
        frame_time=1.0,
        chase_speed_px_per_second=16.0,
        enemy_collision_radius_px=2.0,
        tile_size_px=runtime_map.tile_size_px,
    )

    assert system.enemies[0].world_position == initial_position
    assert system.enemies[0].facing_angle_degrees == 0.0
    assert system.stats.moving_enemies == 0

def test_alerted_enemy_strafes_inside_combat_distance_band() -> None:
    """Alerted enemies should strafe when already at preferred combat distance."""
    from topdown_shooter.world.collision import TileCollisionService

    runtime_map = _build_runtime_map_from_rows(("++++++", "++++++", "++++++", "++++++"))
    system = EnemySystem.from_tactical_map(
        {
            "enemy_spawn_zones": [
                {
                    "id": "spawn_0",
                    "position": [2, 2],
                    "facing_angle_degrees": 0.0,
                },
            ],
        },
        runtime_map,
    )
    enemy = system.enemies[0]
    enemy.alerted = True
    initial_x = enemy.world_position.x

    system.update_chase_movement(
        player_position=WorldCoord(x=88.0, y=40.0),
        collision_service=TileCollisionService(runtime_map),
        frame_time=1.0,
        chase_speed_px_per_second=16.0,
        enemy_collision_radius_px=2.0,
        tile_size_px=runtime_map.tile_size_px,
        preferred_combat_distance_px=48.0,
        combat_distance_tolerance_px=4.0,
        approach_weight=1.0,
        strafe_weight=1.0,
        retreat_weight=1.0,
        strafe_switch_min_seconds=1.0,
        strafe_switch_max_seconds=1.0,
    )

    assert system.enemies[0].world_position.x == initial_x
    assert system.enemies[0].world_position.y != 40.0
    assert system.enemies[0].facing_angle_degrees == 0.0
    assert system.stats.moving_enemies == 1
    assert system.stats.strafing_enemies == 1
    assert system.stats.retreating_enemies == 0


def test_alerted_enemy_retreats_when_too_close_to_player() -> None:
    """Alerted enemies should back away when closer than the combat distance band."""
    from topdown_shooter.world.collision import TileCollisionService

    runtime_map = _build_runtime_map_from_rows(("++++++", "++++++", "++++++", "++++++"))
    system = EnemySystem.from_tactical_map(
        {
            "enemy_spawn_zones": [
                {
                    "id": "spawn_0",
                    "position": [2, 2],
                    "facing_angle_degrees": 0.0,
                },
            ],
        },
        runtime_map,
    )
    enemy = system.enemies[0]
    enemy.alerted = True
    initial_x = enemy.world_position.x

    system.update_chase_movement(
        player_position=WorldCoord(x=56.0, y=40.0),
        collision_service=TileCollisionService(runtime_map),
        frame_time=1.0,
        chase_speed_px_per_second=16.0,
        enemy_collision_radius_px=2.0,
        tile_size_px=runtime_map.tile_size_px,
        preferred_combat_distance_px=48.0,
        combat_distance_tolerance_px=4.0,
        approach_weight=1.0,
        strafe_weight=0.0,
        retreat_weight=1.0,
        strafe_switch_min_seconds=1.0,
        strafe_switch_max_seconds=1.0,
    )

    assert system.enemies[0].world_position.x < initial_x
    assert system.enemies[0].facing_angle_degrees == 0.0
    assert system.stats.moving_enemies == 1
    assert system.stats.strafing_enemies == 0
    assert system.stats.retreating_enemies == 1


def test_alerted_enemy_reports_approach_when_player_is_far() -> None:
    """Alerted enemies should report approach steering outside combat range."""
    from topdown_shooter.world.collision import TileCollisionService

    runtime_map = _build_runtime_map_from_rows(("++++++++", "++++++++", "++++++++", "++++++++"))
    system = EnemySystem.from_tactical_map(
        {
            "enemy_spawn_zones": [
                {
                    "id": "spawn_0",
                    "position": [1, 2],
                    "facing_angle_degrees": 0.0,
                },
            ],
        },
        runtime_map,
    )
    enemy = system.enemies[0]
    enemy.alerted = True

    system.update_chase_movement(
        player_position=WorldCoord(x=120.0, y=40.0),
        collision_service=TileCollisionService(runtime_map),
        frame_time=1.0,
        chase_speed_px_per_second=16.0,
        enemy_collision_radius_px=2.0,
        tile_size_px=runtime_map.tile_size_px,
        preferred_combat_distance_px=48.0,
        combat_distance_tolerance_px=4.0,
        approach_weight=1.0,
        strafe_weight=0.5,
        retreat_weight=1.0,
    )

    assert system.stats.approaching_enemies == 1
    assert system.stats.stuck_enemies == 0


def test_alerted_enemy_uses_smoothed_movement_direction() -> None:
    """Movement smoothing should retain some previous direction across steering changes."""
    from topdown_shooter.world.collision import TileCollisionService

    runtime_map = _build_runtime_map_from_rows(("++++++++", "++++++++", "++++++++", "++++++++"))
    system = EnemySystem.from_tactical_map(
        {
            "enemy_spawn_zones": [
                {
                    "id": "spawn_0",
                    "position": [2, 2],
                    "facing_angle_degrees": 0.0,
                },
            ],
        },
        runtime_map,
    )
    enemy = system.enemies[0]
    enemy.alerted = True
    enemy.movement_direction_x = 1.0
    enemy.movement_direction_y = 0.0

    system.update_chase_movement(
        player_position=WorldCoord(x=40.0, y=88.0),
        collision_service=TileCollisionService(runtime_map),
        frame_time=1.0,
        chase_speed_px_per_second=16.0,
        enemy_collision_radius_px=2.0,
        tile_size_px=runtime_map.tile_size_px,
        preferred_combat_distance_px=0.0,
        approach_weight=1.0,
        movement_direction_smoothing=0.25,
    )

    assert system.enemies[0].movement_direction_x > 0.0
    assert system.enemies[0].movement_direction_y > 0.0


def test_alerted_enemy_reports_stuck_when_no_candidate_is_walkable() -> None:
    """Blocked local candidates should be reported as stuck movement."""
    from topdown_shooter.world.collision import TileCollisionService

    runtime_map = _build_runtime_map_from_rows(("###", "#+#", "###"))
    system = EnemySystem.from_tactical_map(
        {
            "enemy_spawn_zones": [
                {
                    "id": "spawn_0",
                    "position": [1, 1],
                    "facing_angle_degrees": 0.0,
                },
            ],
        },
        runtime_map,
    )
    enemy = system.enemies[0]
    enemy.alerted = True

    system.update_chase_movement(
        player_position=WorldCoord(x=40.0, y=24.0),
        collision_service=TileCollisionService(runtime_map),
        frame_time=1.0,
        chase_speed_px_per_second=16.0,
        enemy_collision_radius_px=2.0,
        tile_size_px=runtime_map.tile_size_px,
        preferred_combat_distance_px=0.0,
        approach_weight=1.0,
    )

    assert system.stats.moving_enemies == 0
    assert system.stats.stuck_enemies == 1


def test_alerted_enemy_uses_pathfinding_when_line_of_sight_is_blocked() -> None:
    """Alerted enemies should route around obstacles when direct sight is blocked."""
    from topdown_shooter.world.collision import TileCollisionService
    from topdown_shooter.world.pathfinding import GridPathfinder

    runtime_map = _build_runtime_map_from_rows(("+++++", "+###+", "+++++"))
    system = EnemySystem.from_tactical_map(
        {
            "enemy_spawn_zones": [
                {
                    "id": "spawn_0",
                    "position": [0, 1],
                    "facing_angle_degrees": 0.0,
                },
            ],
        },
        runtime_map,
    )
    enemy = system.enemies[0]
    enemy.alerted = True

    system.update_chase_movement(
        player_position=WorldCoord(x=72.0, y=24.0),
        collision_service=TileCollisionService(runtime_map),
        frame_time=1.0,
        chase_speed_px_per_second=16.0,
        enemy_collision_radius_px=2.0,
        tile_size_px=runtime_map.tile_size_px,
        preferred_combat_distance_px=0.0,
        approach_weight=1.0,
        pathfinder=GridPathfinder(runtime_map),
        pathfinding_enabled=True,
        path_rebuild_interval_seconds=0.35,
        path_target_rebuild_distance_px=16.0,
        path_max_iterations=64,
        path_waypoint_reach_distance_px=2.0,
    )

    assert system.stats.pathing_enemies == 1
    assert system.stats.path_rebuilds == 1
    assert system.stats.failed_path_rebuilds == 0
    assert system.stats.moving_enemies == 1
    assert system.enemies[0].world_position != WorldCoord(x=8.0, y=24.0)
    assert system.enemies[0].tile != TileCoord(1, 1)


def test_alerted_enemy_reports_failed_path_when_goal_is_unreachable() -> None:
    """Enemy diagnostics should report failed A* path rebuilds."""
    from topdown_shooter.world.collision import TileCollisionService
    from topdown_shooter.world.pathfinding import GridPathfinder

    runtime_map = _build_runtime_map_from_rows(("+#+", "###", "+#+"))
    system = EnemySystem.from_tactical_map(
        {
            "enemy_spawn_zones": [
                {
                    "id": "spawn_0",
                    "position": [0, 0],
                    "facing_angle_degrees": 0.0,
                },
            ],
        },
        runtime_map,
    )
    enemy = system.enemies[0]
    enemy.alerted = True

    system.update_chase_movement(
        player_position=WorldCoord(x=40.0, y=40.0),
        collision_service=TileCollisionService(runtime_map),
        frame_time=1.0,
        chase_speed_px_per_second=16.0,
        enemy_collision_radius_px=2.0,
        tile_size_px=runtime_map.tile_size_px,
        preferred_combat_distance_px=0.0,
        approach_weight=1.0,
        pathfinder=GridPathfinder(runtime_map),
        pathfinding_enabled=True,
        path_rebuild_interval_seconds=0.35,
        path_target_rebuild_distance_px=16.0,
        path_max_iterations=64,
        path_waypoint_reach_distance_px=2.0,
    )

    assert system.stats.path_rebuilds == 1
    assert system.stats.failed_path_rebuilds == 1
    assert system.stats.moving_enemies == 0



def test_stationary_player_triggers_tactical_surround_assignments() -> None:
    """Alerted enemies should get reachable surround slots around a stationary player."""
    from topdown_shooter.world.collision import TileCollisionService
    from topdown_shooter.world.pathfinding import GridPathfinder

    runtime_map = _build_runtime_map_from_rows((
        "++++++++",
        "++++++++",
        "++++++++",
        "++++++++",
        "++++++++",
    ))
    system = EnemySystem.from_tactical_map(
        {
            "enemy_spawn_zones": [
                {"id": "spawn_0", "position": [1, 2], "facing_angle_degrees": 0.0},
                {"id": "spawn_1", "position": [1, 3], "facing_angle_degrees": 0.0},
            ],
        },
        runtime_map,
    )
    for enemy in system.enemies:
        enemy.alerted = True

    system.update_chase_movement(
        player_position=WorldCoord(x=88.0, y=40.0),
        collision_service=TileCollisionService(runtime_map),
        frame_time=1.0,
        chase_speed_px_per_second=16.0,
        enemy_collision_radius_px=2.0,
        tile_size_px=runtime_map.tile_size_px,
        preferred_combat_distance_px=32.0,
        pathfinder=GridPathfinder(runtime_map),
        pathfinding_enabled=True,
        player_speed_px_per_second=0.0,
        tactical_positioning_enabled=True,
        player_stationary_speed_threshold_px_per_second=12.0,
        player_stationary_time_seconds=0.5,
        tactical_slot_count=8,
        tactical_surround_distance_px=32.0,
        tactical_reassign_interval_seconds=1.0,
        tactical_slot_reached_distance_px=6.0,
        tactical_min_slot_spacing_px=16.0,
        path_max_iterations=128,
    )

    assert system.stats.player_stationary is True
    assert system.stats.tactical_positioning_enemies == 2
    assert system.stats.tactical_slots_assigned == 2
    assert all(enemy.tactical_target_position is not None for enemy in system.enemies)
    assert system.stats.pathing_enemies >= 1


def test_moving_player_clears_tactical_surround_assignments() -> None:
    """Tactical surround assignments should clear when the player starts moving."""
    from topdown_shooter.world.collision import TileCollisionService
    from topdown_shooter.world.pathfinding import GridPathfinder

    runtime_map = _build_runtime_map_from_rows((
        "++++++++",
        "++++++++",
        "++++++++",
        "++++++++",
        "++++++++",
    ))
    system = EnemySystem.from_tactical_map(
        {"enemy_spawn_zones": [{"id": "spawn_0", "position": [1, 2]}]},
        runtime_map,
    )
    system.enemies[0].alerted = True
    system.enemies[0].tactical_target_position = WorldCoord(x=88.0, y=24.0)

    system.update_chase_movement(
        player_position=WorldCoord(x=88.0, y=40.0),
        collision_service=TileCollisionService(runtime_map),
        frame_time=0.1,
        chase_speed_px_per_second=16.0,
        enemy_collision_radius_px=2.0,
        tile_size_px=runtime_map.tile_size_px,
        pathfinder=GridPathfinder(runtime_map),
        pathfinding_enabled=True,
        player_speed_px_per_second=80.0,
        tactical_positioning_enabled=True,
        player_stationary_speed_threshold_px_per_second=12.0,
        player_stationary_time_seconds=0.5,
    )

    assert system.stats.player_stationary is False
    assert system.stats.tactical_positioning_enemies == 0
    assert system.enemies[0].tactical_target_position is None


def test_tactical_surround_assignments_use_separate_fire_sectors() -> None:
    """Tactical slots should spread alerted enemies across distinct sectors."""
    import math

    from topdown_shooter.world.collision import TileCollisionService
    from topdown_shooter.world.pathfinding import GridPathfinder

    runtime_map = _build_runtime_map_from_rows((
        "++++++++++",
        "++++++++++",
        "++++++++++",
        "++++++++++",
        "++++++++++",
        "++++++++++",
        "++++++++++",
    ))
    system = EnemySystem.from_tactical_map(
        {
            "enemy_spawn_zones": [
                {"id": "spawn_0", "position": [1, 3]},
                {"id": "spawn_1", "position": [1, 4]},
                {"id": "spawn_2", "position": [1, 5]},
            ],
        },
        runtime_map,
    )
    for enemy in system.enemies:
        enemy.alerted = True

    player_position = WorldCoord(x=88.0, y=56.0)
    system.update_chase_movement(
        player_position=player_position,
        collision_service=TileCollisionService(runtime_map),
        frame_time=1.0,
        chase_speed_px_per_second=16.0,
        enemy_collision_radius_px=2.0,
        tile_size_px=runtime_map.tile_size_px,
        preferred_combat_distance_px=32.0,
        pathfinder=GridPathfinder(runtime_map),
        pathfinding_enabled=True,
        player_speed_px_per_second=0.0,
        tactical_positioning_enabled=True,
        player_stationary_speed_threshold_px_per_second=12.0,
        player_stationary_time_seconds=0.5,
        tactical_slot_count=12,
        tactical_surround_distance_px=32.0,
        tactical_reassign_interval_seconds=0.0,
        tactical_slot_reached_distance_px=6.0,
        tactical_min_slot_spacing_px=8.0,
        tactical_min_slot_angle_degrees=90.0,
        path_max_iterations=128,
    )

    assigned_slots = [enemy.tactical_target_position for enemy in system.enemies]
    assert all(slot is not None for slot in assigned_slots)
    angles = [
        math.degrees(math.atan2(slot.y - player_position.y, slot.x - player_position.x)) % 360.0
        for slot in assigned_slots
        if slot is not None
    ]
    for index, first_angle in enumerate(angles):
        for second_angle in angles[index + 1:]:
            distance = abs((first_angle - second_angle + 180.0) % 360.0 - 180.0)
            assert distance >= 90.0


def test_tactical_surround_assignments_keep_committed_slots() -> None:
    """Tactical slots should not churn while their commitment timer is active."""
    from topdown_shooter.world.collision import TileCollisionService
    from topdown_shooter.world.pathfinding import GridPathfinder

    runtime_map = _build_runtime_map_from_rows((
        "++++++++++",
        "++++++++++",
        "++++++++++",
        "++++++++++",
        "++++++++++",
        "++++++++++",
        "++++++++++",
    ))
    system = EnemySystem.from_tactical_map(
        {
            "enemy_spawn_zones": [
                {"id": "spawn_0", "position": [1, 3]},
                {"id": "spawn_1", "position": [1, 4]},
            ],
        },
        runtime_map,
    )
    for enemy in system.enemies:
        enemy.alerted = True

    collision_service = TileCollisionService(runtime_map)
    pathfinder = GridPathfinder(runtime_map)
    system.update_chase_movement(
        player_position=WorldCoord(x=88.0, y=56.0),
        collision_service=collision_service,
        frame_time=1.0,
        chase_speed_px_per_second=16.0,
        enemy_collision_radius_px=2.0,
        tile_size_px=runtime_map.tile_size_px,
        preferred_combat_distance_px=32.0,
        pathfinder=pathfinder,
        pathfinding_enabled=True,
        player_speed_px_per_second=0.0,
        tactical_positioning_enabled=True,
        player_stationary_speed_threshold_px_per_second=12.0,
        player_stationary_time_seconds=0.5,
        tactical_slot_count=12,
        tactical_surround_distance_px=32.0,
        tactical_reassign_interval_seconds=0.0,
        tactical_slot_commitment_seconds=2.5,
        tactical_player_reposition_distance_px=8.0,
        path_max_iterations=128,
    )
    original_slots = tuple(enemy.tactical_target_position for enemy in system.enemies)

    system.update_chase_movement(
        player_position=WorldCoord(x=104.0, y=56.0),
        collision_service=collision_service,
        frame_time=0.5,
        chase_speed_px_per_second=16.0,
        enemy_collision_radius_px=2.0,
        tile_size_px=runtime_map.tile_size_px,
        preferred_combat_distance_px=32.0,
        pathfinder=pathfinder,
        pathfinding_enabled=True,
        player_speed_px_per_second=0.0,
        tactical_positioning_enabled=True,
        player_stationary_speed_threshold_px_per_second=12.0,
        player_stationary_time_seconds=0.5,
        tactical_slot_count=12,
        tactical_surround_distance_px=32.0,
        tactical_reassign_interval_seconds=0.0,
        tactical_slot_commitment_seconds=2.5,
        tactical_player_reposition_distance_px=8.0,
        path_max_iterations=128,
    )

    assert tuple(enemy.tactical_target_position for enemy in system.enemies) == original_slots


def test_tactical_surround_assignments_cover_multiple_quadrants() -> None:
    """Open-ground tactical assignments should spread enemies around the player."""
    import math

    from topdown_shooter.world.collision import TileCollisionService
    from topdown_shooter.world.pathfinding import GridPathfinder

    runtime_map = _build_runtime_map_from_rows((
        "++++++++++++",
        "++++++++++++",
        "++++++++++++",
        "++++++++++++",
        "++++++++++++",
        "++++++++++++",
        "++++++++++++",
        "++++++++++++",
    ))
    system = EnemySystem.from_tactical_map(
        {
            "enemy_spawn_zones": [
                {"id": "spawn_0", "position": [1, 2]},
                {"id": "spawn_1", "position": [1, 3]},
                {"id": "spawn_2", "position": [1, 4]},
                {"id": "spawn_3", "position": [1, 5]},
            ],
        },
        runtime_map,
    )
    for enemy in system.enemies:
        enemy.alerted = True

    player_position = WorldCoord(x=88.0, y=56.0)
    system.update_chase_movement(
        player_position=player_position,
        collision_service=TileCollisionService(runtime_map),
        frame_time=1.0,
        chase_speed_px_per_second=16.0,
        enemy_collision_radius_px=2.0,
        tile_size_px=runtime_map.tile_size_px,
        preferred_combat_distance_px=32.0,
        pathfinder=GridPathfinder(runtime_map),
        pathfinding_enabled=True,
        player_speed_px_per_second=0.0,
        tactical_positioning_enabled=True,
        player_stationary_speed_threshold_px_per_second=12.0,
        player_stationary_time_seconds=0.5,
        tactical_slot_count=16,
        tactical_surround_distance_px=32.0,
        tactical_reassign_interval_seconds=0.0,
        tactical_slot_reached_distance_px=6.0,
        tactical_min_slot_spacing_px=8.0,
        tactical_min_slot_angle_degrees=60.0,
        path_max_iterations=128,
    )

    assigned_slots = [enemy.tactical_target_position for enemy in system.enemies]
    assert all(slot is not None for slot in assigned_slots)
    quadrants = set()
    for slot in assigned_slots:
        assert slot is not None
        angle = math.degrees(math.atan2(slot.y - player_position.y, slot.x - player_position.x)) % 360.0
        quadrants.add(int(angle // 90.0))
    assert len(quadrants) >= 3


def test_enemy_squad_alert_propagates_after_configured_delay() -> None:
    """Alerting one squad member should alert its squadmates after a delay."""
    runtime_map = _build_runtime_map()
    system = EnemySystem.from_tactical_map(
        {
            "enemy_spawn_zones": [
                {"id": "spawn_0", "position": [1, 1]},
                {"id": "spawn_1", "position": [3, 1]},
            ],
        },
        runtime_map,
        min_squad_size=2,
        max_squad_size=2,
        squad_radius_px=8.0,
        min_enemy_spacing_px=1.0,
        placement_attempts_per_enemy=8,
        enemy_max_health=100.0,
    )
    spawn_zero_enemies = [enemy for enemy in system.enemies if enemy.spawn_id == "spawn_0"]
    spawn_one_enemies = [enemy for enemy in system.enemies if enemy.spawn_id == "spawn_1"]
    assert len(spawn_zero_enemies) == 2
    assert len(spawn_one_enemies) == 2

    hit_enemy = spawn_zero_enemies[0]
    projectile = ProjectileState(
        position=hit_enemy.world_position,
        previous_position=hit_enemy.world_position,
        direction_x=1.0,
        direction_y=0.0,
        speed_px_per_second=16.0,
        max_distance_px=64.0,
        lifetime_seconds=10.0,
        radius_px=3.0,
        damage=10.0,
    )

    system.apply_projectile_hits(
        (projectile,),
        enemy_collision_radius_px=8.0,
        squad_alert_broadcast_delay_seconds=0.5,
    )

    assert hit_enemy.alerted is True
    assert spawn_zero_enemies[1].alerted is False
    assert all(not enemy.alerted for enemy in spawn_one_enemies)
    assert system.stats.pending_squad_alerts == 1

    system.update(0.25, squad_alert_broadcast_delay_seconds=0.5)

    assert spawn_zero_enemies[1].alerted is False
    assert system.stats.pending_squad_alerts == 1

    system.update(0.25, squad_alert_broadcast_delay_seconds=0.5)

    assert spawn_zero_enemies[1].alerted is True
    assert all(not enemy.alerted for enemy in spawn_one_enemies)
    assert system.stats.pending_squad_alerts == 0
    assert system.stats.squad_alerts_triggered == 1


def test_enemy_squad_alert_uses_nearby_fallback_radius() -> None:
    """Alert propagation should include nearby enemies from adjacent spawn anchors."""
    runtime_map = _build_runtime_map_from_rows((
        "++++++++++++",
        "++++++++++++",
        "++++++++++++",
    ))
    system = EnemySystem.from_tactical_map(
        {
            "enemy_spawn_zones": [
                {"id": "spawn_0", "position": [1, 1]},
                {"id": "spawn_1", "position": [2, 1]},
                {"id": "spawn_2", "position": [10, 1]},
            ],
        },
        runtime_map,
        min_squad_size=1,
        max_squad_size=1,
        enemy_max_health=100.0,
    )
    origin = next(enemy for enemy in system.enemies if enemy.spawn_id == "spawn_0")
    nearby = next(enemy for enemy in system.enemies if enemy.spawn_id == "spawn_1")
    far = next(enemy for enemy in system.enemies if enemy.spawn_id == "spawn_2")
    projectile = ProjectileState(
        position=origin.world_position,
        previous_position=origin.world_position,
        direction_x=1.0,
        direction_y=0.0,
        speed_px_per_second=16.0,
        max_distance_px=64.0,
        lifetime_seconds=10.0,
        radius_px=3.0,
        damage=10.0,
    )

    system.apply_projectile_hits(
        (projectile,),
        enemy_collision_radius_px=8.0,
        squad_alert_broadcast_delay_seconds=0.1,
        squad_alert_broadcast_radius_px=48.0,
    )
    system.update(
        0.1,
        squad_alert_broadcast_delay_seconds=0.1,
        squad_alert_broadcast_radius_px=48.0,
    )

    assert origin.alerted is True
    assert nearby.alerted is True
    assert far.alerted is False


def test_enemy_chase_movement_keeps_pending_squad_alerts() -> None:
    """Chase movement should not clear queued squad alert broadcasts."""
    from topdown_shooter.world.collision import TileCollisionService

    runtime_map = _build_runtime_map_from_rows((
        "++++++++++++",
        "++++++++++++",
        "++++++++++++",
    ))
    system = EnemySystem.from_tactical_map(
        {
            "enemy_spawn_zones": [
                {"id": "spawn_0", "position": [1, 1], "facing_angle_degrees": 0.0},
                {"id": "spawn_1", "position": [2, 1], "facing_angle_degrees": 0.0},
            ],
        },
        runtime_map,
        min_squad_size=1,
        max_squad_size=1,
    )

    system.update_perception(
        player_position=WorldCoord(x=48.0, y=24.0),
        collision_service=TileCollisionService(runtime_map),
        vision_range_px=64.0,
        vision_angle_degrees=80.0,
        line_of_sight_sample_step_px=4.0,
        squad_alert_broadcast_delay_seconds=0.5,
        squad_alert_broadcast_radius_px=48.0,
    )

    assert system.stats.pending_squad_alerts == 1

    system.update_chase_movement(
        player_position=WorldCoord(x=48.0, y=24.0),
        collision_service=TileCollisionService(runtime_map),
        frame_time=0.1,
        chase_speed_px_per_second=16.0,
        enemy_collision_radius_px=2.0,
        tile_size_px=runtime_map.tile_size_px,
    )

    assert system.stats.pending_squad_alerts == 1


def test_gunshot_sound_alerts_nearby_enemies_only() -> None:
    """Gunshot sound should alert idle enemies inside the configured noise radius."""
    runtime_map = _build_runtime_map_from_rows((
        "++++++++++",
        "++++++++++",
        "++++++++++",
    ))
    system = EnemySystem.from_tactical_map(
        {
            "enemy_spawn_zones": [
                {"id": "near", "position": [1, 1]},
                {"id": "far", "position": [9, 1]},
            ],
        },
        runtime_map,
    )

    alerted = system.alert_enemies_by_sound(
        origin=WorldCoord(x=24.0, y=24.0),
        noise_radius_px=48.0,
        squad_alert_broadcast_delay_seconds=0.25,
        squad_alert_broadcast_radius_px=0.0,
    )

    assert alerted == 1
    assert system.stats.sound_alerts_triggered == 1
    assert system.enemies[0].alerted is True
    assert system.enemies[1].alerted is False
    assert system.stats.pending_squad_alerts == 0


def test_enemy_awareness_switches_from_engaged_to_searching_when_los_is_lost() -> None:
    """Enemies should become searching after losing direct player visibility."""
    from topdown_shooter.world.collision import TileCollisionService

    runtime_map = _build_runtime_map_from_rows((
        "+++++",
        "+++++",
        "+++++",
    ))
    system = EnemySystem.from_tactical_map(
        {
            "enemy_spawn_zones": [
                {"id": "spawn_0", "position": [1, 1], "facing_angle_degrees": 0.0},
            ],
        },
        runtime_map,
    )
    collision_service = TileCollisionService(runtime_map)

    system.update_perception(
        player_position=WorldCoord(x=56.0, y=24.0),
        collision_service=collision_service,
        vision_range_px=96.0,
        vision_angle_degrees=90.0,
        line_of_sight_sample_step_px=4.0,
    )

    assert system.enemies[0].awareness_state == "engaged"
    assert system.stats.engaged_enemies == 1

    system.update_perception(
        player_position=WorldCoord(x=8.0, y=24.0),
        collision_service=collision_service,
        vision_range_px=96.0,
        vision_angle_degrees=90.0,
        line_of_sight_sample_step_px=4.0,
    )

    assert system.enemies[0].awareness_state == "searching"
    assert system.stats.searching_enemies == 1


def test_searching_enemy_returns_home_after_lost_sight_timeout() -> None:
    """Searching enemies should return home and reset to idle after timeout."""
    from topdown_shooter.world.collision import TileCollisionService

    runtime_map = _build_runtime_map_from_rows((
        "+++++",
        "+++++",
        "+++++",
    ))
    system = EnemySystem.from_tactical_map(
        {
            "enemy_spawn_zones": [
                {"id": "spawn_0", "position": [1, 1], "facing_angle_degrees": 0.0},
            ],
        },
        runtime_map,
    )
    enemy = system.enemies[0]
    enemy.alerted = True
    enemy.awareness_state = "searching"
    enemy.world_position = WorldCoord(x=56.0, y=24.0)
    enemy.tile = world_to_tile(enemy.world_position, runtime_map.tile_size_px)
    enemy.last_seen_player_position = WorldCoord(x=72.0, y=24.0)

    system.update_chase_movement(
        player_position=WorldCoord(x=88.0, y=24.0),
        collision_service=TileCollisionService(runtime_map),
        frame_time=1.1,
        chase_speed_px_per_second=16.0,
        enemy_collision_radius_px=2.0,
        tile_size_px=runtime_map.tile_size_px,
        lost_sight_timeout_seconds=1.0,
    )

    assert enemy.awareness_state == "returning"
    assert system.stats.returning_enemies == 1

    assert enemy.home_position is not None
    enemy.world_position = enemy.home_position
    enemy.tile = world_to_tile(enemy.world_position, runtime_map.tile_size_px)

    system.update_chase_movement(
        player_position=WorldCoord(x=88.0, y=24.0),
        collision_service=TileCollisionService(runtime_map),
        frame_time=0.1,
        chase_speed_px_per_second=16.0,
        enemy_collision_radius_px=2.0,
        tile_size_px=runtime_map.tile_size_px,
        return_home_reached_distance_px=3.0,
    )

    assert enemy.alerted is False
    assert enemy.awareness_state == "idle"
    assert system.stats.alerted_enemies == 0


def test_returning_enemy_moves_to_home_without_combat_distance_hold() -> None:
    """Returning enemies should go home instead of orbiting at combat distance."""
    from topdown_shooter.world.collision import TileCollisionService

    runtime_map = _build_runtime_map_from_rows((
        "++++++",
        "++++++",
        "++++++",
    ))
    system = EnemySystem.from_tactical_map(
        {
            "enemy_spawn_zones": [
                {"id": "spawn_0", "position": [1, 1], "facing_angle_degrees": 90.0},
            ],
        },
        runtime_map,
    )
    enemy = system.enemies[0]
    assert enemy.home_position == WorldCoord(x=24.0, y=24.0)
    enemy.alerted = True
    enemy.awareness_state = "returning"
    enemy.world_position = WorldCoord(x=88.0, y=24.0)
    enemy.tile = world_to_tile(enemy.world_position, runtime_map.tile_size_px)

    system.update_chase_movement(
        player_position=WorldCoord(x=88.0, y=40.0),
        collision_service=TileCollisionService(runtime_map),
        frame_time=1.0,
        chase_speed_px_per_second=16.0,
        enemy_collision_radius_px=2.0,
        tile_size_px=runtime_map.tile_size_px,
        preferred_combat_distance_px=48.0,
        return_home_reached_distance_px=3.0,
    )

    assert enemy.awareness_state == "returning"
    assert enemy.world_position.x < 88.0
    assert enemy.world_position.x == 72.0
    assert system.stats.moving_enemies == 1


def test_returned_enemy_snaps_home_and_restores_initial_facing() -> None:
    """Enemies should reset to idle at home with their original facing angle."""
    from topdown_shooter.world.collision import TileCollisionService

    runtime_map = _build_runtime_map_from_rows((
        "+++++",
        "+++++",
        "+++++",
    ))
    system = EnemySystem.from_tactical_map(
        {
            "enemy_spawn_zones": [
                {"id": "spawn_0", "position": [1, 1], "facing_angle_degrees": 135.0},
            ],
        },
        runtime_map,
    )
    enemy = system.enemies[0]
    assert enemy.home_position is not None
    enemy.alerted = True
    enemy.awareness_state = "returning"
    enemy.world_position = WorldCoord(x=enemy.home_position.x + 2.0, y=enemy.home_position.y)
    enemy.tile = world_to_tile(enemy.world_position, runtime_map.tile_size_px)
    enemy.facing_angle_degrees = 0.0

    system.update_chase_movement(
        player_position=WorldCoord(x=72.0, y=24.0),
        collision_service=TileCollisionService(runtime_map),
        frame_time=0.1,
        chase_speed_px_per_second=16.0,
        enemy_collision_radius_px=2.0,
        tile_size_px=runtime_map.tile_size_px,
        return_home_reached_distance_px=3.0,
    )

    assert enemy.alerted is False
    assert enemy.awareness_state == "idle"
    assert enemy.world_position == enemy.home_position
    assert enemy.facing_angle_degrees == 135.0
    assert system.stats.returned_home_enemies == 1


def test_enemy_system_ignores_enemy_owned_projectiles_for_enemy_damage() -> None:
    """Enemy-owned projectiles should not damage enemies."""
    tactical_map: dict[str, object] = {
        "enemy_spawn_zones": [
            {
                "id": "spawn_0",
                "zone_id": "zone_a",
                "spawn_type": "initial_squad",
                "position": [2, 1],
                "preferred_roles": ["rifleman"],
            },
        ],
    }
    system = EnemySystem.from_tactical_map(
        tactical_map,
        _build_runtime_map(),
        enemy_max_health=50.0,
    )
    projectile = ProjectileState(
        position=WorldCoord(x=48.0, y=24.0),
        previous_position=WorldCoord(x=24.0, y=24.0),
        direction_x=1.0,
        direction_y=0.0,
        speed_px_per_second=16.0,
        max_distance_px=64.0,
        lifetime_seconds=10.0,
        radius_px=3.0,
        damage=50.0,
        owner="enemy",
    )

    system.apply_projectile_hits((projectile,), enemy_collision_radius_px=6.0)

    assert projectile.alive is True
    assert system.stats.active_enemies == 1
    assert system.stats.total_hits == 0
    assert system.enemies[0].health == 50.0


def test_enemy_system_fires_projectile_from_engaged_enemy() -> None:
    """Engaged enemies should spawn hostile projectiles when they see the player."""
    from topdown_shooter.combat.projectiles import ProjectileSystem
    from topdown_shooter.world.collision import TileCollisionService

    tactical_map: dict[str, object] = {
        "enemy_spawn_zones": [
            {
                "id": "spawn_0",
                "zone_id": "zone_a",
                "spawn_type": "initial_squad",
                "position": [1, 1],
                "preferred_roles": ["rifleman"],
            },
        ],
    }
    runtime_map = _build_runtime_map()
    collision_service = TileCollisionService(runtime_map)
    projectile_system = ProjectileSystem(collision_service=collision_service)
    system = EnemySystem.from_tactical_map(tactical_map, runtime_map)
    enemy = system.enemies[0]
    enemy.alerted = True
    enemy.awareness_state = "engaged"

    shots_fired = system.fire_at_player(
        player_position=WorldCoord(56.0, 24.0),
        projectile_system=projectile_system,
        collision_service=collision_service,
        fire_rate_rpm=120.0,
        projectile_speed_px_per_second=200.0,
        projectile_range_px=160.0,
        projectile_lifetime_seconds=1.0,
        projectile_radius_px=2.0,
        damage=7.0,
        max_fire_distance_px=128.0,
        muzzle_offset_px=4.0,
        line_of_sight_sample_step_px=4.0,
    )

    assert shots_fired == 1
    assert enemy.fire_cooldown_seconds == 0.5
    assert projectile_system.projectiles[0].owner == "enemy"
    assert projectile_system.projectiles[0].damage == 7.0
