"""Runtime configuration loading."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any


class RuntimeConfigError(RuntimeError):
    """Raised when runtime configuration cannot be loaded."""


@dataclass(frozen=True, slots=True)
class WindowConfig:
    """Window settings for the runtime.

    Attributes:
        title: Window title.
        target_fps: Target frames per second.
        screen_margin_px: Desired free screen margin on every side.
        width: Resolved runtime window width in pixels.
        height: Resolved runtime window height in pixels.
    """

    title: str
    target_fps: int
    screen_margin_px: int = 100
    width: int = 0
    height: int = 0


@dataclass(frozen=True, slots=True)
class CameraConfig:
    """Camera settings for the runtime.

    Attributes:
        zoom: Initial camera zoom.
        min_zoom: Minimum interactive camera zoom.
        max_zoom: Maximum interactive camera zoom.
        zoom_step: Zoom delta applied by one zoom key press.
        move_speed_px_per_second: Camera pan speed in world pixels per second.
        clamp_to_map: Whether the camera target is clamped to map bounds.
        smooth_time: Inertial follow smoothing time in seconds.
        max_speed_px_per_second: Maximum inertial camera speed in world pixels per second.
        lookahead_tiles: Movement-direction lookahead distance in tiles.
        dead_zone_tiles: Follow dead-zone radius in tiles.
        aim_lookahead_enabled: Whether aim-direction camera offset is enabled.
        aim_lookahead_tiles: Aim-direction camera offset distance in tiles.
        follow_player_by_default: Whether the camera starts in player-follow mode.
    """

    zoom: float
    min_zoom: float
    max_zoom: float
    zoom_step: float
    move_speed_px_per_second: float
    clamp_to_map: bool
    smooth_time: float
    max_speed_px_per_second: float
    lookahead_tiles: float
    dead_zone_tiles: float
    aim_lookahead_enabled: bool
    aim_lookahead_tiles: float
    follow_player_by_default: bool


@dataclass(frozen=True, slots=True)
class PlayerConfig:
    """Player display and movement settings for the runtime.

    Attributes:
        marker_radius_px: Player marker radius in world pixels.
        movement_speed_px_per_second: Player movement speed in world pixels per second.
        collision_radius_px: Player collision radius in world pixels.
        max_health: Initial and maximum player health points.
        fire_muzzle_offset_px: Forward projectile spawn offset from player center.
    """

    marker_radius_px: int
    movement_speed_px_per_second: float
    collision_radius_px: int
    max_health: int
    fire_muzzle_offset_px: float


@dataclass(frozen=True, slots=True)
class AimDebugConfig:
    """Aim debug visualization settings.

    Attributes:
        enabled: Whether the aim direction marker is drawn.
        line_length_px: Aim direction line length in world pixels.
        marker_radius_px: Aim marker radius in world pixels.
        line_thickness_px: Aim direction line thickness in world pixels.
    """

    enabled: bool
    line_length_px: float
    marker_radius_px: float
    line_thickness_px: float


@dataclass(frozen=True, slots=True)
class WeaponsConfig:
    """Weapon database settings for the runtime.

    Attributes:
        database_path: Relative or absolute path to the weapon database JSON file.
    """

    database_path: str


@dataclass(frozen=True, slots=True)
class ImpactParticleConfig:
    """Material impact particle and decal settings.

    Attributes:
        particle_count: Number of visible particles emitted by one impact.
        particle_size_min_px: Minimum particle size in world pixels.
        particle_size_max_px: Maximum particle size in world pixels.
        spread_distance_px: Maximum travel distance from the impact center.
        burst_intensity: Ejection strength multiplier from the impact center.
        decal_enabled: Whether this material leaves a lingering hit mark.
        decal_radius_px: Hit mark radius in world pixels.
        decal_lifetime_seconds: Hit mark lifetime in seconds.
    """

    particle_count: int
    particle_size_min_px: float
    particle_size_max_px: float
    spread_distance_px: float
    burst_intensity: float
    decal_enabled: bool
    decal_radius_px: float
    decal_lifetime_seconds: float


@dataclass(frozen=True, slots=True)
class ProjectileImpactConfig:
    """Projectile impact marker settings.

    Attributes:
        enabled: Whether blocked projectile hits create short-lived markers.
        lifetime_seconds: Flash and particle lifetime in seconds.
        radius_px: Flash and particle radius in world pixels.
        material_effects: Material-specific impact particle and decal settings.
    """

    enabled: bool
    lifetime_seconds: float
    radius_px: float
    material_effects: dict[str, ImpactParticleConfig]

    @property
    def max_lifetime_seconds(self) -> float:
        """Return the retention lifetime required by particles and decals."""
        decal_lifetimes = (
            effect.decal_lifetime_seconds
            for effect in self.material_effects.values()
            if effect.decal_enabled
        )
        return max((self.lifetime_seconds, *decal_lifetimes))


@dataclass(frozen=True, slots=True)
class ShellEjectionConfig:
    """Shell casing ejection visual settings.

    Attributes:
        enabled: Whether every fired shot emits one visible shell casing.
        shell_size_min_px: Minimum shell casing size in world pixels.
        shell_size_max_px: Maximum shell casing size in world pixels.
        lifetime_min_seconds: Minimum shell casing lifetime.
        lifetime_max_seconds: Maximum shell casing lifetime.
        ejection_distance_px: Maximum shell travel distance from the weapon side.
        ejection_intensity: Ejection strength multiplier from the weapon side.
        spread_degrees: Directional spread around the right-side ejection normal.
        max_active_shells: Safety cap for currently retained shell casings.
    """

    enabled: bool
    shell_size_min_px: float
    shell_size_max_px: float
    lifetime_min_seconds: float
    lifetime_max_seconds: float
    ejection_distance_px: float
    ejection_intensity: float
    spread_degrees: float
    max_active_shells: int


@dataclass(frozen=True, slots=True)
class DisabledShellEjectionConfig:
    """Fallback shell ejection settings used by tests and legacy callers."""

    enabled: bool = False
    shell_size_min_px: float = 2.0
    shell_size_max_px: float = 4.0
    lifetime_min_seconds: float = 1.0
    lifetime_max_seconds: float = 2.0
    ejection_distance_px: float = 16.0
    ejection_intensity: float = 1.0
    spread_degrees: float = 35.0
    max_active_shells: int = 2048


@dataclass(frozen=True, slots=True)
class EnemyConfig:
    """Enemy display and health settings.

    Attributes:
        marker_radius_px: Enemy marker radius in world pixels.
        max_health: Initial and maximum health for static enemies.
        hit_marker_lifetime_seconds: Enemy hit marker lifetime in seconds.
        hit_marker_radius_px: Enemy hit marker radius in world pixels.
        health_bar_visible_seconds: Duration for temporary enemy health bars.
        hit_flash_seconds: Duration for enemy hit flash feedback.
        draw_view_cones: Whether debug enemy vision cones are drawn.
        max_debug_view_cones: Maximum enemy view cones drawn per frame. Zero disables them.
        vision_range_px: Enemy vision range in world pixels.
        vision_angle_degrees: Full enemy vision cone angle in degrees.
        line_of_sight_sample_step_px: Sampling step for vision blocked tile checks.
        smart_initial_facing: Whether missing spawn facing is chosen from map geometry.
        facing_candidate_step_degrees: Angle step for smart facing candidates.
        facing_probe_side_angle_degrees: Side probe angle for smart facing scoring.
        facing_wall_penalty_distance_px: Distance threshold for near-wall facing penalties.
        facing_probe_step_px: Sampling step for smart facing probe rays.
        min_squad_size: Minimum enemies generated from one spawn zone.
        max_squad_size: Maximum enemies generated from one spawn zone.
        squad_radius_px: Radius around a spawn zone used for squad placement.
        min_enemy_spacing_px: Minimum initial spacing between enemies.
        max_initial_enemies: Global cap for startup enemies.
        placement_attempts_per_enemy: Candidate attempts for each squad member.
        squad_alert_broadcast_delay_seconds: Delay before a squad alert propagates.
        squad_alert_broadcast_radius_px: Nearby fallback radius for squad alert propagation.
        lost_sight_timeout_seconds: Time before searching enemies return home.
        return_home_reached_distance_px: Distance used to finish return-home behavior.
        chase_speed_px_per_second: Speed for alerted enemy combat movement.
        preferred_combat_distance_px: Desired distance alerted enemies try to keep.
        minimum_combat_distance_px: Hard distance where enemies retreat more aggressively.
        combat_distance_tolerance_px: Distance band around preferred combat distance.
        movement_direction_smoothing: Blend factor for enemy movement direction changes.
        approach_weight: Radial steering weight while closing distance.
        strafe_weight: Tangential steering weight while in combat movement.
        retreat_weight: Radial steering weight while backing away.
        strafe_switch_min_seconds: Minimum time before changing strafe side.
        strafe_switch_max_seconds: Maximum time before changing strafe side.
        pathfinding_enabled: Whether alerted enemies can use grid A* navigation.
        path_rebuild_interval_seconds: Minimum delay between enemy path rebuilds.
        path_target_rebuild_distance_px: Player movement distance that forces path rebuild.
        path_max_iterations: Maximum A* iterations per enemy path query.
        path_max_rebuilds_per_frame: Maximum enemy A* path rebuilds allowed per update.
        path_waypoint_reach_distance_px: Distance used to advance enemy path waypoints.
        draw_enemy_paths: Whether debug enemy A* paths are drawn.
        max_debug_enemy_paths: Maximum enemy A* paths drawn per frame. Zero disables them.
        debug_enemy_render_distance_px: Maximum distance for heavy enemy debug rendering.
        tactical_positioning_enabled: Whether stationary-player tactical slots are used.
        player_stationary_speed_threshold_px_per_second: Speed threshold for stationary player.
        player_stationary_time_seconds: Required stationary time before tactical positioning.
        tactical_slot_count: Number of surround candidate slots around the player.
        tactical_surround_distance_px: Distance from player to tactical slots.
        tactical_reassign_interval_seconds: Minimum delay between tactical slot assignments.
        tactical_slot_reached_distance_px: Distance used to hold a tactical slot.
        tactical_min_slot_spacing_px: Minimum spacing between assigned tactical slots.
        tactical_min_slot_angle_degrees: Minimum angular gap between assigned tactical slots.
        tactical_slot_commitment_seconds: Minimum time tactical slots are held.
        tactical_player_reposition_distance_px: Player movement distance that forces slot reassignment.
        draw_tactical_slots: Whether debug tactical target slots are drawn.
        max_debug_tactical_slots: Maximum tactical slot markers drawn per frame. Zero disables them.
        fire_enabled: Whether engaged enemies can shoot at the player.
        fire_primary_weapon_id: Initial enemy weapon id from the shared weapon database.
        fire_fallback_weapon_id: Backup enemy weapon id used when primary ammo is empty.
        fire_max_distance_px: Maximum distance where enemies are allowed to shoot.
        fire_muzzle_offset_px: Forward projectile spawn offset from enemy center.
        fire_aim_error_degrees: Additional enemy-only aim error cone in degrees.
    """

    marker_radius_px: int
    max_health: float
    hit_marker_lifetime_seconds: float
    hit_marker_radius_px: float
    health_bar_visible_seconds: float
    hit_flash_seconds: float
    draw_view_cones: bool
    max_debug_view_cones: int
    vision_range_px: float
    vision_angle_degrees: float
    line_of_sight_sample_step_px: float
    smart_initial_facing: bool
    facing_candidate_step_degrees: float
    facing_probe_side_angle_degrees: float
    facing_wall_penalty_distance_px: float
    facing_probe_step_px: float
    min_squad_size: int
    max_squad_size: int
    squad_radius_px: float
    min_enemy_spacing_px: float
    max_initial_enemies: int
    placement_attempts_per_enemy: int
    squad_alert_broadcast_delay_seconds: float
    squad_alert_broadcast_radius_px: float
    lost_sight_timeout_seconds: float
    return_home_reached_distance_px: float
    chase_speed_px_per_second: float
    preferred_combat_distance_px: float
    minimum_combat_distance_px: float
    combat_distance_tolerance_px: float
    movement_direction_smoothing: float
    approach_weight: float
    strafe_weight: float
    retreat_weight: float
    strafe_switch_min_seconds: float
    strafe_switch_max_seconds: float
    pathfinding_enabled: bool
    path_rebuild_interval_seconds: float
    path_target_rebuild_distance_px: float
    path_max_iterations: int
    path_max_rebuilds_per_frame: int
    path_waypoint_reach_distance_px: float
    draw_enemy_paths: bool
    max_debug_enemy_paths: int
    debug_enemy_render_distance_px: float
    tactical_positioning_enabled: bool
    player_stationary_speed_threshold_px_per_second: float
    player_stationary_time_seconds: float
    tactical_slot_count: int
    tactical_surround_distance_px: float
    tactical_reassign_interval_seconds: float
    tactical_slot_reached_distance_px: float
    tactical_min_slot_spacing_px: float
    tactical_min_slot_angle_degrees: float
    tactical_slot_commitment_seconds: float
    tactical_player_reposition_distance_px: float
    draw_tactical_slots: bool
    max_debug_tactical_slots: int
    fire_enabled: bool
    fire_primary_weapon_id: str
    fire_fallback_weapon_id: str
    fire_max_distance_px: float
    fire_muzzle_offset_px: float
    fire_aim_error_degrees: float


@dataclass(frozen=True, slots=True)
class UiConfig:
    """Shared UI display settings.

    Attributes:
        font_path: Relative or absolute path to the shared UI TTF font.
        font_spacing: Extra spacing between rendered font glyphs.
        modal_padding: Inner modal panel padding in pixels.
        modal_font_size: Modal text font size in pixels.
        modal_line_spacing: Extra spacing between modal text lines in pixels.
        modal_section_spacing: Extra spacing between modal sections in pixels.
        modal_background_alpha: Modal panel background alpha value in the 0..255 range.
    """

    font_path: str
    font_spacing: float
    modal_padding: int
    modal_font_size: int
    modal_line_spacing: int
    modal_section_spacing: int
    modal_background_alpha: int


@dataclass(frozen=True, slots=True)
class HudConfig:
    """Player HUD display settings.

    Attributes:
        position: HUD anchor position. Supported values are ``top``, ``bottom``,
            ``left``, and ``right``.
        margin_x: Horizontal margin from the selected screen edge.
        margin_y: Vertical margin from the selected screen edge.
        padding: Inner panel padding in pixels.
        font_size: HUD font size in pixels.
        background_alpha: Panel background alpha value in the 0..255 range.
    """

    position: str
    margin_x: int
    margin_y: int
    padding: int
    font_size: int
    background_alpha: int


@dataclass(frozen=True, slots=True)
class Render3DCameraConfig:
    """Experimental 3D follow-camera settings.

    Attributes:
        height: Low-follow camera height above the player in 3D tile units.
        distance: Low-follow camera distance behind the player in 3D tile units.
        look_ahead_tiles: Forward target look-ahead distance in tile units.
        movement_look_ahead_tiles: Smoothed camera anchor offset in movement direction.
        look_ahead_smoothing: Smoothing factor for movement look-ahead offset.
        follow_smoothing: Camera smoothing factor for follow updates.
        top_down_height: Top-down camera height above the player in tile units.
        top_down_back_offset_tiles: Small top-down Z offset to avoid a singular view.
    """

    height: float
    distance: float
    look_ahead_tiles: float
    movement_look_ahead_tiles: float
    look_ahead_smoothing: float
    follow_smoothing: float
    top_down_height: float
    top_down_back_offset_tiles: float


@dataclass(frozen=True, slots=True)
class Render3DPlayerMovementConfig:
    """Experimental 3D player movement settings.

    Attributes:
        movement_speed_tiles_per_second: Maximum player speed in tile units.
        acceleration_tiles_per_second_squared: Acceleration toward requested movement.
        deceleration_tiles_per_second_squared: Braking speed when movement input is released.
        mouse_turn_sensitivity: Mouse yaw sensitivity in radians per pixel.
        invert_mouse_x: Whether horizontal mouse yaw should be inverted.
    """

    movement_speed_tiles_per_second: float
    acceleration_tiles_per_second_squared: float
    deceleration_tiles_per_second_squared: float
    mouse_turn_sensitivity: float
    invert_mouse_x: bool


@dataclass(frozen=True, slots=True)
class Render3DDistanceFadeConfig:
    """Experimental 3D distance fade settings.

    Attributes:
        enabled: Whether distance fade starts enabled.
        fade_start_ratio: Radius ratio where fading begins.
        min_brightness: Minimum brightness multiplier at the render radius edge.
        fog_density: Curve exponent controlling how aggressively distance fog grows.
        keep_markers_bright: Whether gameplay markers ignore distance fade.
    """

    enabled: bool
    fade_start_ratio: float
    min_brightness: float
    fog_density: float
    keep_markers_bright: bool


@dataclass(frozen=True, slots=True)
class Render3DControlsConfig:
    """Experimental 3D renderer control bindings.

    Attributes:
        camera_reset: Key name used to reset only the 3D follow camera smoothing.
        view_mode_toggle: Key name used to cycle 3D view modes.
        distance_fade_toggle: Key name used to toggle distance fade.
        enemy_vision_toggle: Key name used to toggle enemy vision cones.
    """

    camera_reset: str
    view_mode_toggle: str
    distance_fade_toggle: str
    enemy_vision_toggle: str


@dataclass(frozen=True, slots=True)
class Render3DProjectileConfig:
    """Experimental 3D projectile and aim marker settings.

    Attributes:
        draw_aim_line: Whether the player aim line is drawn.
        aim_line_length_tiles: Aim line length in 3D tile units.
        draw_projectiles: Whether active projectile markers are drawn.
        max_visible_projectiles: Maximum projectile markers drawn per frame.
        projectile_radius_tiles: Projectile marker radius in 3D tile units.
        projectile_height_tiles: Projectile marker height above the map in 3D tile units.
        draw_impacts: Whether projectile impact markers are drawn.
        impact_height_tiles: Impact marker height above the map in 3D tile units.
    """

    draw_aim_line: bool
    aim_line_length_tiles: float
    draw_projectiles: bool
    max_visible_projectiles: int
    projectile_radius_tiles: float
    projectile_height_tiles: float
    draw_impacts: bool
    impact_height_tiles: float


@dataclass(frozen=True, slots=True)
class Render3DCombatVisualsConfig:
    """Experimental 3D combat readability settings.

    Attributes:
        draw_projectile_tracers: Whether projectiles draw longer direction tracers.
        projectile_tracer_length_tiles: Projectile tracer length in 3D tile units.
        projectile_tracer_height_offset_tiles: Extra tracer height above projectile markers.
        draw_impact_rings: Whether impacts draw expanding ground rings.
        impact_ring_radius_tiles: Base impact ring radius in 3D tile units.
        impact_ring_height_tiles: Impact ring height above the map in 3D tile units.
        enemy_hit_flash_seconds: Duration for enemy hit flash in 3D seconds.
        draw_enemy_hit_markers: Whether enemy hit markers are drawn in 3D.
        max_visible_enemy_hit_markers: Maximum enemy hit markers drawn per frame.
        enemy_hit_marker_radius_tiles: Enemy hit marker radius in 3D tile units.
        enemy_hit_marker_height_tiles: Enemy hit marker height above the map.
    """

    draw_projectile_tracers: bool
    projectile_tracer_length_tiles: float
    projectile_tracer_height_offset_tiles: float
    draw_impact_rings: bool
    impact_ring_radius_tiles: float
    impact_ring_height_tiles: float
    enemy_hit_flash_seconds: float
    draw_enemy_hit_markers: bool
    max_visible_enemy_hit_markers: int
    enemy_hit_marker_radius_tiles: float
    enemy_hit_marker_height_tiles: float


@dataclass(frozen=True, slots=True)
class Render3DEnemyConfig:
    """Experimental 3D enemy marker settings.

    Attributes:
        draw_enemy_markers: Whether enemy markers are drawn in the 3D experiment.
        max_visible_enemies: Maximum enemy markers drawn per frame.
        marker_radius_tiles: Enemy marker radius in 3D tile units.
        marker_height_tiles: Enemy marker height in 3D tile units.
        direction_line_length_tiles: Enemy facing line length in 3D tile units.
    """

    draw_enemy_markers: bool
    max_visible_enemies: int
    marker_radius_tiles: float
    marker_height_tiles: float
    direction_line_length_tiles: float


@dataclass(frozen=True, slots=True)
class Render3DEnemyVisionConfig:
    """Experimental 3D enemy vision cone visualization settings.

    Attributes:
        enabled: Whether enemy vision cones start enabled.
        max_visible_cones: Maximum enemy vision cones drawn per frame.
        cone_segments: Number of arc segments used for one cone.
        height_tiles: Height above the map where vision lines are drawn.
        range_scale: Multiplier applied to the runtime enemy vision range.
        idle_alpha: Alpha used for idle enemy cones.
        alert_alpha: Alpha used for alerted/searching enemy cones.
        combat_alpha: Alpha used for engaged enemy cones.
    """

    enabled: bool
    max_visible_cones: int
    cone_segments: int
    height_tiles: float
    range_scale: float
    idle_alpha: int
    alert_alpha: int
    combat_alpha: int


@dataclass(frozen=True, slots=True)
class Render3DConfig:
    """Experimental 3D renderer settings.

    Attributes:
        enabled: Whether the experimental 3D renderer is enabled by config.
        view_radius_tiles: Radius around the player/camera used for 3D culling.
        tile_size: 3D world size of one map tile.
        height_scale: Multiplier for generated 3D primitive heights.
        render_mode: Default 3D render mode. Supported values are ``optimized``
            and ``per_tile``.
        view_mode: Default 3D view mode. Supported values are ``clean``,
            ``gameplay``, and ``debug``.
        max_visible_primitives: Safety cap for visible primitive rendering.
        camera: Follow-camera settings.
        player_movement: Experimental 3D player movement settings.
        controls: Experimental 3D control bindings.
        distance_fade: Experimental 3D distance fade settings.
        enemies: Experimental 3D enemy marker settings.
        enemy_vision: Experimental 3D enemy vision cone settings.
        projectiles: Experimental 3D projectile marker settings.
        combat_visuals: Experimental 3D combat readability settings.
    """

    enabled: bool
    view_radius_tiles: int
    tile_size: float
    height_scale: float
    render_mode: str
    view_mode: str
    max_visible_primitives: int
    camera: Render3DCameraConfig
    player_movement: Render3DPlayerMovementConfig
    controls: Render3DControlsConfig
    distance_fade: Render3DDistanceFadeConfig
    enemies: Render3DEnemyConfig
    enemy_vision: Render3DEnemyVisionConfig
    projectiles: Render3DProjectileConfig
    combat_visuals: Render3DCombatVisualsConfig


@dataclass(frozen=True, slots=True)
class ControlsConfig:
    """Input binding names for the runtime.

    Attributes:
        quit: Key name used to close the runtime window.
        help: Key name used to toggle the controls help overlay.
        mouse_capture_toggle: Key name used to release or capture the mouse in 3D.
        camera_up: Key names used to pan the camera up.
        camera_down: Key names used to pan the camera down.
        camera_left: Key names used to pan the camera left.
        camera_right: Key names used to pan the camera right.
        camera_zoom_in: Key name used to zoom the camera in.
        camera_zoom_out: Key name used to zoom the camera out.
        camera_zoom_mouse_wheel: Whether mouse wheel zoom is enabled.
        camera_reset: Key name used to reset the camera to the map start tile.
        camera_toggle_follow: Key name used to toggle player-follow camera mode.
        player_up: Key names used to move the player up.
        player_down: Key names used to move the player down.
        player_left: Key names used to move the player left.
        player_right: Key names used to move the player right.
        fire_primary: Mouse button name used to fire the current weapon.
        reload: Key name used to reload the current weapon.
        weapon_slot_1: Key name used to equip weapon slot 1.
        weapon_slot_2: Key name used to equip weapon slot 2.
        weapon_slot_3: Key name used to equip weapon slot 3.
        interact: Key name used to interact with nearby runtime objects.
    """

    quit: str
    help: str
    mouse_capture_toggle: str
    camera_up: tuple[str, ...]
    camera_down: tuple[str, ...]
    camera_left: tuple[str, ...]
    camera_right: tuple[str, ...]
    camera_zoom_in: str
    camera_zoom_out: str
    camera_zoom_mouse_wheel: bool
    camera_reset: str
    camera_toggle_follow: str
    player_up: tuple[str, ...]
    player_down: tuple[str, ...]
    player_left: tuple[str, ...]
    player_right: tuple[str, ...]
    fire_primary: str
    reload: str
    weapon_slot_1: str
    weapon_slot_2: str
    weapon_slot_3: str
    interact: str


@dataclass(frozen=True, slots=True)
class RuntimeConfig:
    """Top-level runtime configuration.

    Attributes:
        window: Window settings.
        camera: Camera settings.
        player: Player display settings.
        aim_debug: Aim debug display settings.
        weapons: Weapon database settings.
        projectile_impacts: Projectile impact marker settings.
        shell_ejection: Shell casing ejection visual settings.
        enemies: Enemy marker display settings.
        ui: Shared UI display settings.
        hud: Player HUD display settings.
        render3d: Experimental 3D renderer settings.
        controls: Control bindings.
    """

    window: WindowConfig
    camera: CameraConfig
    player: PlayerConfig
    aim_debug: AimDebugConfig
    weapons: WeaponsConfig
    projectile_impacts: ProjectileImpactConfig
    shell_ejection: ShellEjectionConfig
    enemies: EnemyConfig
    ui: UiConfig
    hud: HudConfig
    render3d: Render3DConfig
    controls: ControlsConfig


class RuntimeConfigLoader:
    """Load runtime configuration files."""

    def load_default(self) -> RuntimeConfig:
        """Load the default runtime configuration from ``res/config``.

        Returns:
            Runtime configuration.
        """
        config_path = self._default_config_path()
        try:
            with config_path.open("r", encoding="utf-8") as config_file:
                raw_config = json.load(config_file)
        except OSError as exc:
            raise RuntimeConfigError(
                f"Default runtime config cannot be read: {config_path}",
            ) from exc
        except json.JSONDecodeError as exc:
            raise RuntimeConfigError(
                f"Default runtime config contains invalid JSON: {config_path}",
            ) from exc
        if not isinstance(raw_config, dict):
            raise RuntimeConfigError("Default runtime config root must be an object.")
        return self._build_config(raw_config)

    @staticmethod
    def _default_config_path() -> Path:
        """Return the project default runtime config path.

        Returns:
            Path to ``res/config/default_runtime_config.json``.
        """
        return (
            Path(__file__).resolve().parents[3]
            / "res"
            / "config"
            / "default_runtime_config.json"
        )

    def _build_config(self, raw_config: dict[str, Any]) -> RuntimeConfig:
        """Build typed runtime config from raw data.

        Args:
            raw_config: Raw configuration dictionary.

        Returns:
            Runtime configuration.
        """
        window = self._require_dict(raw_config, "window")
        camera = self._require_dict(raw_config, "camera")
        player = self._require_dict(raw_config, "player")
        aim_debug = self._require_dict(raw_config, "aim_debug")
        weapons = self._require_dict(raw_config, "weapons")
        projectile_impacts = self._require_dict(raw_config, "projectile_impacts")
        shell_ejection = self._require_dict(raw_config, "shell_ejection")
        enemies = self._require_dict(raw_config, "enemies")
        ui = self._require_dict(raw_config, "ui")
        hud = self._require_dict(raw_config, "hud")
        render3d = self._require_dict(raw_config, "render3d")
        controls = self._require_dict(raw_config, "controls")
        return RuntimeConfig(
            window=WindowConfig(
                title=self._require_str(window, "title"),
                target_fps=self._require_positive_int(window, "target_fps"),
                screen_margin_px=self._require_non_negative_int(
                    window,
                    "screen_margin_px",
                ),
            ),
            camera=self._build_camera_config(camera),
            player=PlayerConfig(
                marker_radius_px=self._require_positive_int(player, "marker_radius_px"),
                movement_speed_px_per_second=self._require_positive_float(
                    player,
                    "movement_speed_px_per_second",
                ),
                collision_radius_px=self._require_non_negative_int(
                    player,
                    "collision_radius_px",
                ),
                max_health=self._require_positive_int(player, "max_health"),
                fire_muzzle_offset_px=self._require_non_negative_float(
                    player,
                    "fire_muzzle_offset_px",
                ),
            ),
            aim_debug=AimDebugConfig(
                enabled=self._require_bool(aim_debug, "enabled"),
                line_length_px=self._require_positive_float(aim_debug, "line_length_px"),
                marker_radius_px=self._require_positive_float(aim_debug, "marker_radius_px"),
                line_thickness_px=self._require_positive_float(
                    aim_debug,
                    "line_thickness_px",
                ),
            ),
            weapons=WeaponsConfig(
                database_path=self._require_str(weapons, "database_path"),
            ),
            projectile_impacts=ProjectileImpactConfig(
                enabled=self._require_bool(projectile_impacts, "enabled"),
                lifetime_seconds=self._require_positive_float(
                    projectile_impacts,
                    "lifetime_seconds",
                ),
                radius_px=self._require_positive_float(projectile_impacts, "radius_px"),
                material_effects=self._build_impact_material_effects(projectile_impacts),
            ),
            shell_ejection=ShellEjectionConfig(
                enabled=self._require_bool(shell_ejection, "enabled"),
                shell_size_min_px=self._require_float_pair_min(
                    shell_ejection,
                    "shell_size_px",
                ),
                shell_size_max_px=self._require_float_pair_max(
                    shell_ejection,
                    "shell_size_px",
                ),
                lifetime_min_seconds=self._require_float_pair_min(
                    shell_ejection,
                    "lifetime_seconds",
                ),
                lifetime_max_seconds=self._require_float_pair_max(
                    shell_ejection,
                    "lifetime_seconds",
                ),
                ejection_distance_px=self._require_positive_float(
                    shell_ejection,
                    "ejection_distance_px",
                ),
                ejection_intensity=self._require_positive_float(
                    shell_ejection,
                    "ejection_intensity",
                ),
                spread_degrees=self._require_non_negative_float(
                    shell_ejection,
                    "spread_degrees",
                ),
                max_active_shells=self._require_positive_int(
                    shell_ejection,
                    "max_active_shells",
                ),
            ),
            enemies=EnemyConfig(
                marker_radius_px=self._require_positive_int(enemies, "marker_radius_px"),
                max_health=self._require_positive_float(enemies, "max_health"),
                hit_marker_lifetime_seconds=self._require_positive_float(
                    enemies,
                    "hit_marker_lifetime_seconds",
                ),
                hit_marker_radius_px=self._require_positive_float(
                    enemies,
                    "hit_marker_radius_px",
                ),
                health_bar_visible_seconds=self._require_positive_float(
                    enemies,
                    "health_bar_visible_seconds",
                ),
                hit_flash_seconds=self._require_positive_float(
                    enemies,
                    "hit_flash_seconds",
                ),
                draw_view_cones=self._require_bool(enemies, "draw_view_cones"),
                max_debug_view_cones=self._require_non_negative_int(
                    enemies,
                    "max_debug_view_cones",
                ),
                vision_range_px=self._require_positive_float(enemies, "vision_range_px"),
                vision_angle_degrees=self._require_angle_degrees(
                    enemies,
                    "vision_angle_degrees",
                ),
                line_of_sight_sample_step_px=self._require_positive_float(
                    enemies,
                    "line_of_sight_sample_step_px",
                ),
                smart_initial_facing=self._require_bool(enemies, "smart_initial_facing"),
                facing_candidate_step_degrees=self._require_angle_degrees(
                    enemies,
                    "facing_candidate_step_degrees",
                ),
                facing_probe_side_angle_degrees=self._require_angle_degrees(
                    enemies,
                    "facing_probe_side_angle_degrees",
                ),
                facing_wall_penalty_distance_px=self._require_positive_float(
                    enemies,
                    "facing_wall_penalty_distance_px",
                ),
                facing_probe_step_px=self._require_positive_float(
                    enemies,
                    "facing_probe_step_px",
                ),
                min_squad_size=self._require_positive_int(enemies, "min_squad_size"),
                max_squad_size=self._require_positive_int(enemies, "max_squad_size"),
                squad_radius_px=self._require_non_negative_float(
                    enemies,
                    "squad_radius_px",
                ),
                min_enemy_spacing_px=self._require_non_negative_float(
                    enemies,
                    "min_enemy_spacing_px",
                ),
                max_initial_enemies=self._require_non_negative_int(
                    enemies,
                    "max_initial_enemies",
                ),
                placement_attempts_per_enemy=self._require_positive_int(
                    enemies,
                    "placement_attempts_per_enemy",
                ),
                squad_alert_broadcast_delay_seconds=self._require_non_negative_float(
                    enemies,
                    "squad_alert_broadcast_delay_seconds",
                ),
                squad_alert_broadcast_radius_px=self._require_non_negative_float(
                    enemies,
                    "squad_alert_broadcast_radius_px",
                ),
                lost_sight_timeout_seconds=self._require_non_negative_float(
                    enemies,
                    "lost_sight_timeout_seconds",
                ),
                return_home_reached_distance_px=self._require_non_negative_float(
                    enemies,
                    "return_home_reached_distance_px",
                ),
                chase_speed_px_per_second=self._require_non_negative_float(
                    enemies,
                    "chase_speed_px_per_second",
                ),
                preferred_combat_distance_px=self._require_non_negative_float(
                    enemies,
                    "preferred_combat_distance_px",
                ),
                minimum_combat_distance_px=self._require_non_negative_float(
                    enemies,
                    "minimum_combat_distance_px",
                ),
                combat_distance_tolerance_px=self._require_non_negative_float(
                    enemies,
                    "combat_distance_tolerance_px",
                ),
                movement_direction_smoothing=self._require_non_negative_float(
                    enemies,
                    "movement_direction_smoothing",
                ),
                approach_weight=self._require_non_negative_float(enemies, "approach_weight"),
                strafe_weight=self._require_non_negative_float(enemies, "strafe_weight"),
                retreat_weight=self._require_non_negative_float(enemies, "retreat_weight"),
                strafe_switch_min_seconds=self._require_non_negative_float(
                    enemies,
                    "strafe_switch_min_seconds",
                ),
                strafe_switch_max_seconds=self._require_non_negative_float(
                    enemies,
                    "strafe_switch_max_seconds",
                ),
                pathfinding_enabled=self._require_bool(enemies, "pathfinding_enabled"),
                path_rebuild_interval_seconds=self._require_non_negative_float(
                    enemies,
                    "path_rebuild_interval_seconds",
                ),
                path_target_rebuild_distance_px=self._require_non_negative_float(
                    enemies,
                    "path_target_rebuild_distance_px",
                ),
                path_max_iterations=self._require_positive_int(enemies, "path_max_iterations"),
                path_max_rebuilds_per_frame=self._require_non_negative_int(
                    enemies,
                    "path_max_rebuilds_per_frame",
                ),
                path_waypoint_reach_distance_px=self._require_non_negative_float(
                    enemies,
                    "path_waypoint_reach_distance_px",
                ),
                draw_enemy_paths=self._require_bool(enemies, "draw_enemy_paths"),
                max_debug_enemy_paths=self._require_non_negative_int(
                    enemies,
                    "max_debug_enemy_paths",
                ),
                debug_enemy_render_distance_px=self._require_non_negative_float(
                    enemies,
                    "debug_enemy_render_distance_px",
                ),
                tactical_positioning_enabled=self._require_bool(
                    enemies,
                    "tactical_positioning_enabled",
                ),
                player_stationary_speed_threshold_px_per_second=(
                    self._require_non_negative_float(
                        enemies,
                        "player_stationary_speed_threshold_px_per_second",
                    )
                ),
                player_stationary_time_seconds=self._require_non_negative_float(
                    enemies,
                    "player_stationary_time_seconds",
                ),
                tactical_slot_count=self._require_positive_int(
                    enemies,
                    "tactical_slot_count",
                ),
                tactical_surround_distance_px=self._require_non_negative_float(
                    enemies,
                    "tactical_surround_distance_px",
                ),
                tactical_reassign_interval_seconds=self._require_non_negative_float(
                    enemies,
                    "tactical_reassign_interval_seconds",
                ),
                tactical_slot_reached_distance_px=self._require_non_negative_float(
                    enemies,
                    "tactical_slot_reached_distance_px",
                ),
                tactical_min_slot_spacing_px=self._require_non_negative_float(
                    enemies,
                    "tactical_min_slot_spacing_px",
                ),
                tactical_min_slot_angle_degrees=self._require_angle_degrees(
                    enemies,
                    "tactical_min_slot_angle_degrees",
                ),
                tactical_slot_commitment_seconds=self._require_non_negative_float(
                    enemies,
                    "tactical_slot_commitment_seconds",
                ),
                tactical_player_reposition_distance_px=self._require_non_negative_float(
                    enemies,
                    "tactical_player_reposition_distance_px",
                ),
                draw_tactical_slots=self._require_bool(enemies, "draw_tactical_slots"),
                max_debug_tactical_slots=self._require_non_negative_int(
                    enemies,
                    "max_debug_tactical_slots",
                ),
                fire_enabled=self._require_bool(enemies, "fire_enabled"),
                fire_primary_weapon_id=self._require_str(
                    enemies,
                    "fire_primary_weapon_id",
                ),
                fire_fallback_weapon_id=self._require_str(
                    enemies,
                    "fire_fallback_weapon_id",
                ),
                fire_max_distance_px=self._require_positive_float(
                    enemies,
                    "fire_max_distance_px",
                ),
                fire_muzzle_offset_px=self._require_non_negative_float(
                    enemies,
                    "fire_muzzle_offset_px",
                ),
                fire_aim_error_degrees=self._require_non_negative_float(
                    enemies,
                    "fire_aim_error_degrees",
                ),
            ),
            ui=UiConfig(
                font_path=self._require_str(ui, "font_path"),
                font_spacing=self._require_non_negative_float(ui, "font_spacing"),
                modal_padding=self._require_non_negative_int(ui, "modal_padding"),
                modal_font_size=self._require_positive_int(ui, "modal_font_size"),
                modal_line_spacing=self._require_non_negative_int(ui, "modal_line_spacing"),
                modal_section_spacing=self._require_non_negative_int(
                    ui,
                    "modal_section_spacing",
                ),
                modal_background_alpha=self._require_alpha(ui, "modal_background_alpha"),
            ),
            hud=HudConfig(
                position=self._require_str(hud, "position"),
                margin_x=self._require_non_negative_int(hud, "margin_x"),
                margin_y=self._require_non_negative_int(hud, "margin_y"),
                padding=self._require_non_negative_int(hud, "padding"),
                font_size=self._require_positive_int(hud, "font_size"),
                background_alpha=self._require_alpha(hud, "background_alpha"),
            ),
            render3d=self._build_render3d_config(render3d),
            controls=ControlsConfig(
                quit=self._require_str(controls, "quit"),
                help=self._require_str(controls, "help"),
                mouse_capture_toggle=self._require_str(controls, "mouse_capture_toggle"),
                camera_up=self._require_key_names(controls, "camera_up"),
                camera_down=self._require_key_names(controls, "camera_down"),
                camera_left=self._require_key_names(controls, "camera_left"),
                camera_right=self._require_key_names(controls, "camera_right"),
                camera_zoom_in=self._require_str(controls, "camera_zoom_in"),
                camera_zoom_out=self._require_str(controls, "camera_zoom_out"),
                camera_zoom_mouse_wheel=self._require_bool(
                    controls,
                    "camera_zoom_mouse_wheel",
                ),
                camera_reset=self._require_str(controls, "camera_reset"),
                camera_toggle_follow=self._require_str(controls, "camera_toggle_follow"),
                player_up=self._require_key_names(controls, "player_up"),
                player_down=self._require_key_names(controls, "player_down"),
                player_left=self._require_key_names(controls, "player_left"),
                player_right=self._require_key_names(controls, "player_right"),
                fire_primary=self._require_str(controls, "fire_primary"),
                reload=self._require_str(controls, "reload"),
                weapon_slot_1=self._require_str(controls, "weapon_slot_1"),
                weapon_slot_2=self._require_str(controls, "weapon_slot_2"),
                weapon_slot_3=self._require_str(controls, "weapon_slot_3"),
                interact=self._require_str(controls, "interact"),
            ),
        )

    def _build_render3d_config(self, render3d: dict[str, Any]) -> Render3DConfig:
        """Build typed experimental 3D renderer config from raw data.

        Args:
            render3d: Raw 3D renderer configuration dictionary.

        Returns:
            Experimental 3D renderer configuration.
        """
        camera = self._require_dict(render3d, "camera")
        player_movement = self._require_dict(render3d, "player_movement")
        controls = self._require_dict(render3d, "controls")
        distance_fade = self._require_dict(render3d, "distance_fade")
        enemies = self._require_dict(render3d, "enemies")
        enemy_vision = self._require_dict(render3d, "enemy_vision")
        projectiles = self._require_dict(render3d, "projectiles")
        combat_visuals = self._require_dict(render3d, "combat_visuals")
        render_mode = self._require_render3d_mode(render3d, "render_mode")
        view_mode = self._require_render3d_view_mode(render3d, "view_mode")
        return Render3DConfig(
            enabled=self._require_bool(render3d, "enabled"),
            view_radius_tiles=self._require_positive_int(render3d, "view_radius_tiles"),
            tile_size=self._require_positive_float(render3d, "tile_size"),
            height_scale=self._require_positive_float(render3d, "height_scale"),
            render_mode=render_mode,
            view_mode=view_mode,
            max_visible_primitives=self._require_positive_int(
                render3d,
                "max_visible_primitives",
            ),
            camera=Render3DCameraConfig(
                height=self._require_positive_float(camera, "height"),
                distance=self._require_positive_float(camera, "distance"),
                look_ahead_tiles=self._require_non_negative_float(
                    camera,
                    "look_ahead_tiles",
                ),
                movement_look_ahead_tiles=self._require_non_negative_float(
                    camera,
                    "movement_look_ahead_tiles",
                ),
                look_ahead_smoothing=self._require_non_negative_float(
                    camera,
                    "look_ahead_smoothing",
                ),
                follow_smoothing=self._require_non_negative_float(
                    camera,
                    "follow_smoothing",
                ),
                top_down_height=self._require_positive_float(
                    camera,
                    "top_down_height",
                ),
                top_down_back_offset_tiles=self._require_positive_float(
                    camera,
                    "top_down_back_offset_tiles",
                ),
            ),
            player_movement=Render3DPlayerMovementConfig(
                movement_speed_tiles_per_second=self._require_positive_float(
                    player_movement,
                    "movement_speed_tiles_per_second",
                ),
                acceleration_tiles_per_second_squared=self._require_positive_float(
                    player_movement,
                    "acceleration_tiles_per_second_squared",
                ),
                deceleration_tiles_per_second_squared=self._require_positive_float(
                    player_movement,
                    "deceleration_tiles_per_second_squared",
                ),
                mouse_turn_sensitivity=self._require_positive_float(
                    player_movement,
                    "mouse_turn_sensitivity",
                ),
                invert_mouse_x=self._require_bool(
                    player_movement,
                    "invert_mouse_x",
                ),
            ),
            controls=Render3DControlsConfig(
                camera_reset=self._require_str(controls, "camera_reset"),
                view_mode_toggle=self._require_str(controls, "view_mode_toggle"),
                distance_fade_toggle=self._require_str(
                    controls,
                    "distance_fade_toggle",
                ),
                enemy_vision_toggle=self._require_str(
                    controls,
                    "enemy_vision_toggle",
                ),
            ),
            distance_fade=Render3DDistanceFadeConfig(
                enabled=self._require_bool(distance_fade, "enabled"),
                fade_start_ratio=self._require_unit_interval_float(
                    distance_fade,
                    "fade_start_ratio",
                ),
                min_brightness=self._require_unit_interval_float(
                    distance_fade,
                    "min_brightness",
                ),
                fog_density=self._require_positive_float(
                    distance_fade,
                    "fog_density",
                ),
                keep_markers_bright=self._require_bool(
                    distance_fade,
                    "keep_markers_bright",
                ),
            ),
            projectiles=Render3DProjectileConfig(
                draw_aim_line=self._require_bool(
                    projectiles,
                    "draw_aim_line",
                ),
                aim_line_length_tiles=self._require_positive_float(
                    projectiles,
                    "aim_line_length_tiles",
                ),
                draw_projectiles=self._require_bool(
                    projectiles,
                    "draw_projectiles",
                ),
                max_visible_projectiles=self._require_positive_int(
                    projectiles,
                    "max_visible_projectiles",
                ),
                projectile_radius_tiles=self._require_positive_float(
                    projectiles,
                    "projectile_radius_tiles",
                ),
                projectile_height_tiles=self._require_positive_float(
                    projectiles,
                    "projectile_height_tiles",
                ),
                draw_impacts=self._require_bool(
                    projectiles,
                    "draw_impacts",
                ),
                impact_height_tiles=self._require_positive_float(
                    projectiles,
                    "impact_height_tiles",
                ),
            ),
            combat_visuals=Render3DCombatVisualsConfig(
                draw_projectile_tracers=self._require_bool(
                    combat_visuals,
                    "draw_projectile_tracers",
                ),
                projectile_tracer_length_tiles=self._require_positive_float(
                    combat_visuals,
                    "projectile_tracer_length_tiles",
                ),
                projectile_tracer_height_offset_tiles=self._require_non_negative_float(
                    combat_visuals,
                    "projectile_tracer_height_offset_tiles",
                ),
                draw_impact_rings=self._require_bool(
                    combat_visuals,
                    "draw_impact_rings",
                ),
                impact_ring_radius_tiles=self._require_positive_float(
                    combat_visuals,
                    "impact_ring_radius_tiles",
                ),
                impact_ring_height_tiles=self._require_non_negative_float(
                    combat_visuals,
                    "impact_ring_height_tiles",
                ),
                enemy_hit_flash_seconds=self._require_positive_float(
                    combat_visuals,
                    "enemy_hit_flash_seconds",
                ),
                draw_enemy_hit_markers=self._require_bool(
                    combat_visuals,
                    "draw_enemy_hit_markers",
                ),
                max_visible_enemy_hit_markers=self._require_positive_int(
                    combat_visuals,
                    "max_visible_enemy_hit_markers",
                ),
                enemy_hit_marker_radius_tiles=self._require_positive_float(
                    combat_visuals,
                    "enemy_hit_marker_radius_tiles",
                ),
                enemy_hit_marker_height_tiles=self._require_non_negative_float(
                    combat_visuals,
                    "enemy_hit_marker_height_tiles",
                ),
            ),
            enemies=Render3DEnemyConfig(
                draw_enemy_markers=self._require_bool(
                    enemies,
                    "draw_enemy_markers",
                ),
                max_visible_enemies=self._require_positive_int(
                    enemies,
                    "max_visible_enemies",
                ),
                marker_radius_tiles=self._require_positive_float(
                    enemies,
                    "marker_radius_tiles",
                ),
                marker_height_tiles=self._require_positive_float(
                    enemies,
                    "marker_height_tiles",
                ),
                direction_line_length_tiles=self._require_positive_float(
                    enemies,
                    "direction_line_length_tiles",
                ),
            ),
            enemy_vision=Render3DEnemyVisionConfig(
                enabled=self._require_bool(enemy_vision, "enabled"),
                max_visible_cones=self._require_positive_int(
                    enemy_vision,
                    "max_visible_cones",
                ),
                cone_segments=self._require_positive_int(
                    enemy_vision,
                    "cone_segments",
                ),
                height_tiles=self._require_non_negative_float(
                    enemy_vision,
                    "height_tiles",
                ),
                range_scale=self._require_positive_float(
                    enemy_vision,
                    "range_scale",
                ),
                idle_alpha=self._require_alpha_int(enemy_vision, "idle_alpha"),
                alert_alpha=self._require_alpha_int(enemy_vision, "alert_alpha"),
                combat_alpha=self._require_alpha_int(enemy_vision, "combat_alpha"),
            ),
        )

    def _build_impact_material_effects(
        self,
        projectile_impacts: dict[str, Any],
    ) -> dict[str, ImpactParticleConfig]:
        """Build material-specific impact particle configuration.

        Args:
            projectile_impacts: Raw projectile impact configuration section.

        Returns:
            Validated material effect mapping.
        """
        raw_effects = self._require_dict(projectile_impacts, "material_effects")
        effects: dict[str, ImpactParticleConfig] = {}
        for material_name, raw_effect in raw_effects.items():
            if not isinstance(material_name, str) or not material_name.strip():
                raise RuntimeConfigError("Runtime config impact material key is invalid.")
            if not isinstance(raw_effect, dict):
                raise RuntimeConfigError(
                    "Runtime config impact material effect must be an object: "
                    f"{material_name}",
                )
            effects[material_name.strip()] = ImpactParticleConfig(
                particle_count=self._require_positive_int(
                    raw_effect,
                    "particle_count",
                ),
                particle_size_min_px=self._require_float_pair_min(
                    raw_effect,
                    "particle_size_px",
                ),
                particle_size_max_px=self._require_float_pair_max(
                    raw_effect,
                    "particle_size_px",
                ),
                spread_distance_px=self._require_positive_float(
                    raw_effect,
                    "spread_distance_px",
                ),
                burst_intensity=self._require_positive_float(
                    raw_effect,
                    "burst_intensity",
                ),
                decal_enabled=self._require_bool(
                    raw_effect,
                    "decal_enabled",
                ),
                decal_radius_px=self._require_non_negative_float(
                    raw_effect,
                    "decal_radius_px",
                ),
                decal_lifetime_seconds=self._require_non_negative_float(
                    raw_effect,
                    "decal_lifetime_seconds",
                ),
            )
            effect = effects[material_name.strip()]
            if effect.decal_enabled and (
                effect.decal_radius_px <= 0.0
                or effect.decal_lifetime_seconds <= 0.0
            ):
                raise RuntimeConfigError(
                    "Runtime config enabled impact decal must have positive radius "
                    f"and lifetime: {material_name}",
                )
        if "default" not in effects:
            raise RuntimeConfigError(
                "Runtime config projectile impact effects must include 'default'.",
            )
        return effects

    def _require_symbol_tuple(self, data: dict[str, Any], key: str) -> tuple[str, ...]:
        """Read one-character tile symbols from runtime config."""
        value = data.get(key)
        if not isinstance(value, list) or not value:
            raise RuntimeConfigError(f"Runtime config symbol list is missing: {key}")
        symbols: list[str] = []
        for item in value:
            if not isinstance(item, str) or len(item) != 1:
                raise RuntimeConfigError(f"Runtime config symbol list is invalid: {key}")
            symbols.append(item)
        return tuple(symbols)

    def _require_alpha_int(self, data: dict[str, Any], field: str) -> int:
        """Read a color alpha channel value from 0 to 255.

        Args:
            data: Source mapping.
            field: Field name to read.

        Returns:
            Validated integer alpha value.

        Raises:
            RuntimeConfigError: If the value is outside the allowed range.
        """
        value = self._require_non_negative_int(data, field)
        if value > 255:
            raise RuntimeConfigError(
                "Runtime config field "
                f"'{field}' must be less than or equal to 255.",
            )
        return value

    def _require_render3d_mode(self, data: dict[str, Any], field: str) -> str:
        """Read and validate an experimental 3D render mode.

        Args:
            data: Source mapping.
            field: Field name to read.

        Returns:
            Validated render mode.

        Raises:
            RuntimeConfigError: If the render mode value is unsupported.
        """
        value = self._require_str(data, field)
        if value not in {"optimized", "per_tile"}:
            raise RuntimeConfigError(
                "Runtime config field "
                f"'{field}' must be 'optimized' or 'per_tile'.",
            )
        return value

    def _require_render3d_view_mode(self, data: dict[str, Any], field: str) -> str:
        """Read and validate an experimental 3D view mode.

        Args:
            data: Source mapping.
            field: Field name to read.

        Returns:
            Validated view mode.

        Raises:
            RuntimeConfigError: If the view mode value is unsupported.
        """
        value = self._require_str(data, field)
        if value not in {"clean", "gameplay", "debug"}:
            raise RuntimeConfigError(
                "Runtime config field "
                f"'{field}' must be 'clean', 'gameplay', or 'debug'.",
            )
        return value

    def _build_camera_config(self, camera: dict[str, Any]) -> CameraConfig:
        """Build typed camera config from raw data.

        Args:
            camera: Raw camera configuration dictionary.

        Returns:
            Camera configuration.
        """
        zoom = self._require_positive_float(camera, "zoom")
        min_zoom = self._require_positive_float(camera, "min_zoom")
        max_zoom = self._require_positive_float(camera, "max_zoom")
        if min_zoom > max_zoom:
            raise RuntimeConfigError("Runtime config camera zoom range is invalid.")
        if zoom < min_zoom or zoom > max_zoom:
            raise RuntimeConfigError("Runtime config camera zoom is outside the configured range.")
        return CameraConfig(
            zoom=zoom,
            min_zoom=min_zoom,
            max_zoom=max_zoom,
            zoom_step=self._require_positive_float(camera, "zoom_step"),
            move_speed_px_per_second=self._require_positive_float(
                camera,
                "move_speed_px_per_second",
            ),
            clamp_to_map=self._require_bool(camera, "clamp_to_map"),
            smooth_time=self._require_non_negative_float(camera, "smooth_time"),
            max_speed_px_per_second=self._require_non_negative_float(
                camera,
                "max_speed_px_per_second",
            ),
            lookahead_tiles=self._require_non_negative_float(camera, "lookahead_tiles"),
            dead_zone_tiles=self._require_non_negative_float(camera, "dead_zone_tiles"),
            aim_lookahead_enabled=self._require_bool(camera, "aim_lookahead_enabled"),
            aim_lookahead_tiles=self._require_non_negative_float(camera, "aim_lookahead_tiles"),
            follow_player_by_default=self._require_bool(camera, "follow_player_by_default"),
        )

    def _require_dict(self, data: dict[str, Any], key: str) -> dict[str, Any]:
        """Return a required dictionary value.

        Args:
            data: Source dictionary.
            key: Required key.

        Returns:
            Nested dictionary.
        """
        value = data.get(key)
        if not isinstance(value, dict):
            raise RuntimeConfigError(f"Runtime config section is missing or invalid: {key}")
        return value

    def _require_str(self, data: dict[str, Any], key: str) -> str:
        """Return a required string value.

        Args:
            data: Source dictionary.
            key: Required key.

        Returns:
            String value.
        """
        value = data.get(key)
        if not isinstance(value, str) or not value.strip():
            raise RuntimeConfigError(f"Runtime config string is missing or invalid: {key}")
        return value

    def _require_positive_int(self, data: dict[str, Any], key: str) -> int:
        """Return a required positive integer value.

        Args:
            data: Source dictionary.
            key: Required key.

        Returns:
            Positive integer value.
        """
        value = data.get(key)
        if not isinstance(value, int) or value <= 0:
            raise RuntimeConfigError(f"Runtime config integer is missing or invalid: {key}")
        return value

    def _require_non_negative_int(self, data: dict[str, Any], key: str) -> int:
        """Return a required non-negative integer value.

        Args:
            data: Source dictionary.
            key: Required key.

        Returns:
            Non-negative integer value.
        """
        value = data.get(key)
        if not isinstance(value, int) or value < 0:
            raise RuntimeConfigError(f"Runtime config integer is missing or invalid: {key}")
        return value

    def _require_angle_degrees(self, data: dict[str, Any], key: str) -> float:
        """Return an angle value in the 0..360 range.

        Args:
            data: Source dictionary.
            key: Required key.

        Returns:
            Angle value in degrees.
        """
        value = self._require_positive_float(data, key)
        if value > 360.0:
            raise RuntimeConfigError(f"Runtime config angle is out of range: {key}")
        return value

    def _require_alpha(self, data: dict[str, Any], key: str) -> int:
        """Return a required alpha value.

        Args:
            data: Source dictionary.
            key: Required key.

        Returns:
            Alpha value in the 0..255 range.
        """
        value = self._require_non_negative_int(data, key)
        if value > 255:
            raise RuntimeConfigError(f"Runtime config alpha is out of range: {key}")
        return value

    def _require_bool(self, data: dict[str, Any], key: str) -> bool:
        """Return a required boolean value.

        Args:
            data: Source dictionary.
            key: Required key.

        Returns:
            Boolean value.
        """
        value = data.get(key)
        if not isinstance(value, bool):
            raise RuntimeConfigError(f"Runtime config boolean is missing or invalid: {key}")
        return value

    def _require_positive_float(self, data: dict[str, Any], key: str) -> float:
        """Return a required positive float value.

        Args:
            data: Source dictionary.
            key: Required key.

        Returns:
            Positive float value.
        """
        value = data.get(key)
        if not isinstance(value, int | float) or value <= 0:
            raise RuntimeConfigError(f"Runtime config number is missing or invalid: {key}")
        return float(value)

    def _require_non_negative_float(self, data: dict[str, Any], key: str) -> float:
        """Return a required non-negative float value.

        Args:
            data: Source dictionary.
            key: Required key.

        Returns:
            Non-negative float value.
        """
        value = data.get(key)
        if not isinstance(value, int | float) or value < 0:
            raise RuntimeConfigError(f"Runtime config number is missing or invalid: {key}")
        return float(value)

    def _require_unit_interval_float(self, data: dict[str, Any], key: str) -> float:
        """Read and validate a float value in the 0..1 range."""
        value = self._require_non_negative_float(data, key)
        if value > 1.0:
            raise RuntimeConfigError(
                f"Runtime config field '{key}' must be less than or equal to 1.0.",
            )
        return value

    def _require_float_pair_min(self, data: dict[str, Any], key: str) -> float:
        """Return the validated lower value from a two-number range."""
        return self._require_positive_float_pair(data, key)[0]

    def _require_float_pair_max(self, data: dict[str, Any], key: str) -> float:
        """Return the validated upper value from a two-number range."""
        return self._require_positive_float_pair(data, key)[1]

    def _require_positive_float_pair(
        self,
        data: dict[str, Any],
        key: str,
    ) -> tuple[float, float]:
        """Read a positive inclusive numeric range from config."""
        value = data.get(key)
        if (
            not isinstance(value, list)
            or len(value) != 2
            or not all(isinstance(item, int | float) for item in value)
        ):
            raise RuntimeConfigError(
                f"Runtime config number range is missing or invalid: {key}",
            )
        min_value = float(value[0])
        max_value = float(value[1])
        if min_value <= 0.0 or max_value <= 0.0 or min_value > max_value:
            raise RuntimeConfigError(
                f"Runtime config number range is invalid: {key}",
            )
        return min_value, max_value

    def _require_key_names(self, data: dict[str, Any], key: str) -> tuple[str, ...]:
        """Return one or more required key names.

        Args:
            data: Source dictionary.
            key: Required key.

        Returns:
            Key name tuple.
        """
        value = data.get(key)
        if isinstance(value, str) and value.strip():
            return (value,)
        if isinstance(value, list) and value and all(
            isinstance(item, str) and item.strip() for item in value
        ):
            return tuple(value)
        raise RuntimeConfigError(f"Runtime config key list is missing or invalid: {key}")

