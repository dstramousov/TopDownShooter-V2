"""Experimental raylib 3D renderer."""

from __future__ import annotations

from dataclasses import dataclass, replace
import math

from topdown_shooter.combat.enemies import EnemyHitMarkerState, EnemySystem
from topdown_shooter.combat.projectiles import (
    ImpactMarkerState,
    ProjectileEvent,
    ProjectileEventType,
    ProjectileOwner,
    ProjectileState,
    ProjectileSystem,
    SurfaceMaterial,
)
from topdown_shooter.combat.weapons import WeaponController
from topdown_shooter.config.runtime_config import RuntimeConfig
from topdown_shooter.gameplay.camera_feedback import CameraFeedbackSystem
from topdown_shooter.gameplay.combat_runtime import update_combat_runtime
from topdown_shooter.gameplay.explosions import RuntimeExplosionSystem
from topdown_shooter.gameplay.interactions import RuntimeObjectInteractionSystem
from topdown_shooter.experimental.render3d.camera import (
    Render3DCameraState,
    Render3DFollowCamera,
    Render3DVector,
)
from topdown_shooter.experimental.render3d.scene import (
    Render3DSceneBuilder,
    Render3DSceneSnapshot,
    Render3DTilePrimitive,
)
from topdown_shooter.map_loading.package_loader import GeneratedMapPackage
from topdown_shooter.rendering.combat_feedback import CombatFeedbackOverlay
from topdown_shooter.rendering.fps_counter import FpsCounter
from topdown_shooter.rendering.player_hud import PlayerHud
from topdown_shooter.rendering.raylib_input import (
    RaylibInputResolver,
    configure_raylib_logging,
    is_any_key_down,
)
from topdown_shooter.rendering.raylib_window import import_raylib
from topdown_shooter.rendering.window_layout import (
    apply_raylib_window_position,
    resolve_raylib_window_layout,
)
from topdown_shooter.ui.runtime_ui import ControlsHelpLine, RuntimeUi
from topdown_shooter.world.collision import TileCollisionService
from topdown_shooter.world.coordinates import WorldCoord
from topdown_shooter.world.pathfinding import GridPathfinder
from topdown_shooter.world.player import PlayerState
from topdown_shooter.world.player_aim import PlayerAimState
from topdown_shooter.world.player_controller import PlayerController, PlayerMoveIntent
from topdown_shooter.world.runtime_map import RuntimeMap, RuntimeMapObject


@dataclass(frozen=True, slots=True)
class Render3DInputState:
    """Current experimental 3D input state.

    Attributes:
        move_x: Horizontal movement direction.
        move_y: Vertical movement direction.
    """

    move_x: float
    move_y: float


@dataclass(slots=True)
class _Render3DMuzzleFlashState:
    """Short-lived 3D muzzle flash state."""

    position: WorldCoord
    owner: ProjectileOwner
    visual_profile: str = "default"
    age_seconds: float = 0.0
    lifetime_seconds: float = 0.09


@dataclass(slots=True)
class _Render3DProjectileTrailState:
    """Short-lived 3D projectile trail segment."""

    previous_position: WorldCoord
    position: WorldCoord
    owner: ProjectileOwner
    visual_profile: str
    key: tuple[int, int, int, int, str, str]
    age_seconds: float = 0.0
    lifetime_seconds: float = 0.075


@dataclass(slots=True)
class _Render3DShellCasingState:
    """Short-lived 3D shell casing state."""

    origin: WorldCoord
    direction_x: float
    direction_y: float
    size_px: float
    travel_distance_px: float
    owner: ProjectileOwner
    visual_profile: str
    age_seconds: float = 0.0
    lifetime_seconds: float = 1.0


class Render3DRenderer:
    """Draw a minimal experimental 3D view of the current runtime map."""

    CLEAN_VIEW_MODE = "clean"
    GAMEPLAY_VIEW_MODE = "gameplay"
    DEBUG_VIEW_MODE = "debug"
    VIEW_MODE_ORDER = (CLEAN_VIEW_MODE, GAMEPLAY_VIEW_MODE, DEBUG_VIEW_MODE)
    _POSITION_RETRY_FRAMES = 12
    _ENVIRONMENT_DETAIL_RADIUS_TILES = 18

    def __init__(
        self,
        runtime_map: RuntimeMap,
        package: GeneratedMapPackage,
        config: RuntimeConfig,
    ) -> None:
        """Initialize the renderer.

        Args:
            runtime_map: Runtime map owned by the game.
            package: Loaded generated map package.
            config: Runtime configuration.
        """
        self._runtime_map = runtime_map
        self._package = package
        self._raylib = import_raylib()
        self._input = RaylibInputResolver(self._raylib)
        self._window_layout = resolve_raylib_window_layout(self._raylib, config.window)
        self._pending_window_position_frames = self._POSITION_RETRY_FRAMES
        self._config = replace(config, window=self._window_layout.window)
        config = self._config
        self._camera_mode = Render3DFollowCamera.LOW_FOLLOW_MODE
        self._view_mode = config.render3d.view_mode
        self._last_facing_x = 0.0
        self._last_facing_y = -1.0
        self._velocity_x_px_per_second = 0.0
        self._velocity_y_px_per_second = 0.0
        self._camera_forward_x = 0.0
        self._camera_forward_y = -1.0
        self._player_key_left = self._resolve_player_keys(
            config.controls.player_left,
            fallback_key_names=("KEY_LEFT",),
        )
        self._player_key_right = self._resolve_player_keys(
            config.controls.player_right,
            fallback_key_names=("KEY_RIGHT",),
        )
        self._player_key_up = self._resolve_player_keys(
            config.controls.player_up,
            fallback_key_names=("KEY_UP",),
        )
        self._player_key_down = self._resolve_player_keys(
            config.controls.player_down,
            fallback_key_names=("KEY_DOWN",),
        )
        self._key_reset = self._resolve_key(config.render3d.controls.camera_reset)
        self._key_view_mode = self._resolve_key(config.render3d.controls.view_mode_toggle)
        self._key_distance_fade = self._resolve_key(
            config.render3d.controls.distance_fade_toggle,
        )
        self._key_enemy_vision = self._resolve_key(
            config.render3d.controls.enemy_vision_toggle,
        )
        self._mouse_capture_toggle_key = self._resolve_key(config.controls.mouse_capture_toggle)
        self._mouse_capture_desired = True
        self._mouse_capture_active = False
        self._fire_primary_button = self._resolve_mouse_button(config.controls.fire_primary)
        self._reload_key = self._resolve_key(config.controls.reload)
        self._weapon_slot_1_key = self._resolve_key(config.controls.weapon_slot_1)
        self._weapon_slot_2_key = self._resolve_key(config.controls.weapon_slot_2)
        self._weapon_slot_3_key = self._resolve_key(config.controls.weapon_slot_3)
        self._interact_key = self._resolve_key(config.controls.interact)
        self._interaction_system = RuntimeObjectInteractionSystem()
        self._explosion_system = RuntimeExplosionSystem()
        self._weapon_fire_events_last_update = 0
        self._muzzle_flashes: list[_Render3DMuzzleFlashState] = []
        self._projectile_trails: list[_Render3DProjectileTrailState] = []
        self._projectile_trail_keys: set[tuple[int, int, int, int, str, str]] = set()
        self._shell_casings: list[_Render3DShellCasingState] = []
        self._shell_sequence = 0
        self._combat_feedback = CombatFeedbackOverlay(
            raylib=self._raylib,
            window=config.window,
        )
        self._camera_feedback = CameraFeedbackSystem()
        self._distance_fade_enabled = config.render3d.distance_fade.enabled
        self._enemy_vision_enabled = config.render3d.enemy_vision.enabled
        self._player_hud = PlayerHud(
            raylib=self._raylib,
            config=config.hud,
            window=config.window,
            font_path=config.ui.font_path,
            font_spacing=config.ui.font_spacing,
        )
        self._fps_counter = FpsCounter(
            raylib=self._raylib,
            window=config.window,
            ui=config.ui,
        )
        self._ui = RuntimeUi(
            raylib=self._raylib,
            config=config,
            renderer_name="3D",
            help_lines=self._build_help_lines(config),
        )

    def run_follow_preview(
        self,
        player: PlayerState,
        player_controller: PlayerController,
        scene_builder: Render3DSceneBuilder,
        camera_controller: Render3DFollowCamera,
        enemy_system: EnemySystem,
        projectile_system: ProjectileSystem,
        weapon_controller: WeaponController,
        collision_service: TileCollisionService,
        enemy_pathfinder: GridPathfinder,
    ) -> None:
        """Run the first interactive 3D follow-camera preview.

        Args:
            player: Mutable player state used by the experiment.
            player_controller: Runtime player movement controller.
            scene_builder: View-radius scene builder.
            camera_controller: Smoothed 3D follow-camera controller.
            enemy_system: Runtime enemies drawn as 3D markers.
            projectile_system: Runtime projectile system used for 3D fire preview.
            weapon_controller: Weapon controller used by the isolated 3D experiment.
            collision_service: Tile collision service shared by runtime systems.
            enemy_pathfinder: Grid pathfinder used by the existing enemy AI.
        """
        raylib = self._raylib
        window = self._config.window
        self._configure_raylib_logging()
        raylib.init_window(window.width, window.height, f"{window.title} - 3D experiment")
        raylib.set_exit_key(raylib.KEY_NULL)
        self._apply_initial_window_position()
        raylib.set_target_fps(window.target_fps)
        self._set_mouse_capture(True)
        scene = scene_builder.build_snapshot(player.tile)
        try:
            while not raylib.window_should_close():
                self._apply_initial_window_position()
                ui_input = self._ui.handle_input()
                if ui_input.should_exit:
                    break
                if raylib.is_key_pressed(self._mouse_capture_toggle_key) and not ui_input.blocks_gameplay:
                    self._mouse_capture_desired = not self._mouse_capture_desired
                self._set_mouse_capture(self._mouse_capture_desired and not ui_input.blocks_gameplay)
                frame_time = raylib.get_frame_time()
                if not ui_input.blocks_gameplay:
                    self._update_camera_mode(camera_controller)
                    if self._mouse_capture_active:
                        self._update_facing_from_mouse()
                    input_state = self._read_input_state()
                    self._update_player(player, player_controller, input_state, frame_time)
                    self._update_combat_controls(
                        player=player,
                        weapon_controller=weapon_controller,
                        frame_time=frame_time,
                    )
                    self._update_interactions(
                        player=player,
                        weapon_controller=weapon_controller,
                        frame_time=frame_time,
                    )
                    update_combat_runtime(
                        player=player,
                        enemy_system=enemy_system,
                        projectile_system=projectile_system,
                        weapon_controller=weapon_controller,
                        collision_service=collision_service,
                        pathfinder=enemy_pathfinder,
                        runtime_map=self._runtime_map,
                        config=self._config,
                        frame_time=frame_time,
                        weapon_fire_events=self._weapon_fire_events_last_update,
                        player_speed_px_per_second=self._player_speed_px_per_second(),
                    )
                    explosion_results = self._explosion_system.process_projectile_events(
                        events=projectile_system.events,
                        runtime_map=self._runtime_map,
                        player=player,
                        enemy_system=enemy_system,
                        projectile_system=projectile_system,
                    )
                    projectile_events = projectile_system.consume_events()
                    self._add_projectile_events(projectile_events)
                    self._combat_feedback.add_events(projectile_events)
                    self._camera_feedback.add_projectile_events(
                        projectile_events,
                        player_position=player.world_position,
                        tile_size_px=self._runtime_map.tile_size_px,
                    )
                    self._camera_feedback.add_explosions(
                        explosion_results,
                        player_position=player.world_position,
                        tile_size_px=self._runtime_map.tile_size_px,
                    )
                    scene = scene_builder.build_snapshot(player.tile)
                visible_enemies = self._visible_enemies(
                    enemies=enemy_system.enemies,
                    player_position=player.world_position,
                )
                visible_projectiles = self._visible_projectiles(
                    projectiles=projectile_system.projectiles,
                    player_position=player.world_position,
                )
                visible_impacts = self._visible_impacts(
                    impacts=projectile_system.impacts,
                    player_position=player.world_position,
                )
                visible_enemy_hit_markers = self._visible_enemy_hit_markers(
                    hit_markers=enemy_system.hit_markers,
                    player_position=player.world_position,
                )
                camera_state = camera_controller.build_state(
                    player_position=player.world_position,
                    facing_x=self._last_facing_x,
                    facing_y=self._last_facing_y,
                    frame_time=frame_time,
                    mode=self._camera_mode,
                )
                self._update_camera_relative_basis(camera_state)
                active_frame_time = frame_time if not ui_input.blocks_gameplay else 0.0
                self._update_muzzle_flashes(active_frame_time)
                self._update_projectile_trails(active_frame_time)
                self._update_shell_casings(active_frame_time)
                self._combat_feedback.update(active_frame_time)
                self._camera_feedback.update(active_frame_time)
                camera_state = self._apply_camera_feedback(camera_state)
                camera = raylib.Camera3D(
                    raylib.Vector3(
                        camera_state.position.x,
                        camera_state.position.y,
                        camera_state.position.z,
                    ),
                    raylib.Vector3(
                        camera_state.target.x,
                        camera_state.target.y,
                        camera_state.target.z,
                    ),
                    raylib.Vector3(0.0, 1.0, 0.0),
                    60.0,
                    raylib.CAMERA_PERSPECTIVE,
                )
                raylib.begin_drawing()
                raylib.clear_background(raylib.BLACK)
                raylib.begin_mode_3d(camera)
                self._draw_scene(scene)
                if self._view_mode_draws_gameplay_markers():
                    self._draw_enemy_vision_cones(visible_enemies)
                    self._draw_enemy_markers(visible_enemies)
                    self._draw_muzzle_flashes()
                    self._draw_projectile_markers(visible_projectiles)
                    self._draw_shell_casings()
                    self._draw_impact_markers(visible_impacts)
                    self._draw_aim_line(
                        player.world_position,
                        self._last_facing_x,
                        self._last_facing_y,
                    )
                if self._view_mode_draws_debug_markers():
                    self._draw_enemy_hit_markers(visible_enemy_hit_markers)
                self._draw_player_marker(
                    player.world_position,
                    self._last_facing_x,
                    self._last_facing_y,
                )
                raylib.end_mode_3d()
                self._player_hud.draw(
                    player,
                    weapon_controller.stats,
                    damage_pulse=self._combat_feedback.hud_damage_pulse,
                    status_message=self._interaction_system.active_message,
                )
                self._combat_feedback.draw()
                self._fps_counter.draw()
                self._ui.draw()
                raylib.end_drawing()
        finally:
            self._player_hud.unload()
            self._fps_counter.unload()
            self._ui.unload()
            self._set_mouse_capture(False)
            raylib.close_window()


    @staticmethod
    def _build_help_lines(config: RuntimeConfig) -> tuple[ControlsHelpLine, ...]:
        """Build 3D controls help lines from runtime bindings."""
        return (
            ControlsHelpLine("Mouse X", "turn view / facing"),
            ControlsHelpLine("W/S", "move forward / backpedal"),
            ControlsHelpLine("A/D", "strafe left / right"),
            ControlsHelpLine(config.controls.fire_primary, "fire"),
            ControlsHelpLine("1/2/3", "select weapon"),
            ControlsHelpLine(config.controls.reload, "reload"),
            ControlsHelpLine(config.controls.interact, "interact / use cache"),
            ControlsHelpLine(config.controls.mouse_capture_toggle, "capture / release mouse"),
            ControlsHelpLine(config.render3d.controls.camera_reset, "reset camera"),
            ControlsHelpLine(config.render3d.controls.view_mode_toggle, "view mode"),
            ControlsHelpLine(config.render3d.controls.distance_fade_toggle, "fog / fade"),
            ControlsHelpLine(config.render3d.controls.enemy_vision_toggle, "enemy vision cones"),
            ControlsHelpLine(config.controls.help, "pause / controls"),
            ControlsHelpLine(config.controls.quit, "exit confirmation"),
        )

    def _apply_initial_window_position(self) -> None:
        """Re-apply startup window position for window managers that defer placement."""
        if self._pending_window_position_frames <= 0:
            return
        apply_raylib_window_position(self._raylib, self._window_layout)
        self._pending_window_position_frames -= 1

    def _update_camera_mode(self, camera_controller: Render3DFollowCamera) -> None:
        """Apply 3D camera and view hotkeys."""
        raylib = self._raylib
        if raylib.is_key_pressed(self._key_reset):
            camera_controller.reset()
        if raylib.is_key_pressed(self._key_view_mode):
            self._view_mode = self._next_view_mode(self._view_mode)
        if raylib.is_key_pressed(self._key_distance_fade):
            self._distance_fade_enabled = not self._distance_fade_enabled
        if raylib.is_key_pressed(self._key_enemy_vision):
            self._enemy_vision_enabled = not self._enemy_vision_enabled

    @classmethod
    def _next_view_mode(cls, current_mode: str) -> str:
        """Return the next 3D view mode in the configured cycle."""
        try:
            current_index = cls.VIEW_MODE_ORDER.index(current_mode)
        except ValueError:
            return cls.GAMEPLAY_VIEW_MODE
        next_index = (current_index + 1) % len(cls.VIEW_MODE_ORDER)
        return cls.VIEW_MODE_ORDER[next_index]

    def _view_mode_draws_gameplay_markers(self) -> bool:
        """Return whether current view mode should draw gameplay objects."""
        return self._view_mode in {self.GAMEPLAY_VIEW_MODE, self.DEBUG_VIEW_MODE}

    def _view_mode_draws_debug_markers(self) -> bool:
        """Return whether current view mode should draw debug-only objects."""
        return self._view_mode == self.DEBUG_VIEW_MODE

    def _read_input_state(self) -> Render3DInputState:
        """Read movement input for the experimental 3D player loop."""
        move_x = 0.0
        move_y = 0.0
        if self._is_any_key_down(self._player_key_left):
            move_x -= 1.0
        if self._is_any_key_down(self._player_key_right):
            move_x += 1.0
        if self._is_any_key_down(self._player_key_up):
            move_y -= 1.0
        if self._is_any_key_down(self._player_key_down):
            move_y += 1.0
        return Render3DInputState(move_x=move_x, move_y=move_y)


    def _update_interactions(
        self,
        *,
        player: PlayerState,
        weapon_controller: WeaponController,
        frame_time: float,
    ) -> None:
        """Apply nearby runtime object interactions in 3D gameplay."""
        self._interaction_system.update(frame_time)
        if not self._raylib.is_key_pressed(self._interact_key):
            return
        self._interaction_system.try_interact(
            runtime_map=self._runtime_map,
            player=player,
            weapon_controller=weapon_controller,
        )

    def _update_player(
        self,
        player: PlayerState,
        player_controller: PlayerController,
        input_state: Render3DInputState,
        frame_time: float,
    ) -> None:
        """Update facing-relative movement without rotating from movement input."""
        if frame_time <= 0.0:
            return

        movement_x, movement_y = self._facing_relative_movement(
            input_state=input_state,
            facing_x=self._last_facing_x,
            facing_y=self._last_facing_y,
        )
        self._update_velocity(movement_x, movement_y, frame_time)
        velocity_length = math.hypot(
            self._velocity_x_px_per_second,
            self._velocity_y_px_per_second,
        )
        if velocity_length > 0.01:
            player_controller.update(
                player=player,
                intent=PlayerMoveIntent(
                    x=self._velocity_x_px_per_second,
                    y=self._velocity_y_px_per_second,
                ),
                frame_time=frame_time,
                speed_px_per_second=velocity_length,
            )
        self._update_player_aim(player)


    def _update_combat_controls(
        self,
        player: PlayerState,
        weapon_controller: WeaponController,
        frame_time: float,
    ) -> None:
        """Update isolated 3D experiment weapon controls.

        Args:
            player: Current player state used as projectile origin and aim source.
            weapon_controller: Weapon controller owned by the 3D experiment.
            frame_time: Current frame duration in seconds.
        """
        raylib = self._raylib
        if raylib.is_key_pressed(self._weapon_slot_1_key):
            weapon_controller.switch_to_slot(1)
        if raylib.is_key_pressed(self._weapon_slot_2_key):
            weapon_controller.switch_to_slot(2)
        if raylib.is_key_pressed(self._weapon_slot_3_key):
            weapon_controller.switch_to_slot(3)
        if raylib.is_key_pressed(self._reload_key):
            weapon_controller.reload_current()

        self._weapon_fire_events_last_update = weapon_controller.update(
            fire_held=raylib.is_mouse_button_down(self._fire_primary_button),
            frame_time=frame_time,
            origin=player.world_position,
            direction_x=player.aim.direction_x,
            direction_y=player.aim.direction_y,
            muzzle_offset_px=self._config.player.fire_muzzle_offset_px,
        )

    def _update_facing_from_mouse(self) -> None:
        """Rotate visual facing from horizontal mouse movement."""
        mouse_delta = self._raylib.get_mouse_delta()
        delta_x = float(mouse_delta.x)
        if abs(delta_x) <= 0.0001:
            return
        movement_config = self._config.render3d.player_movement
        yaw_delta = delta_x * movement_config.mouse_turn_sensitivity
        if movement_config.invert_mouse_x:
            yaw_delta = -yaw_delta
        current_angle = math.atan2(self._last_facing_y, self._last_facing_x)
        new_angle = current_angle + yaw_delta
        self._last_facing_x = math.cos(new_angle)
        self._last_facing_y = math.sin(new_angle)

    @staticmethod
    def _facing_relative_movement(
        input_state: Render3DInputState,
        facing_x: float,
        facing_y: float,
    ) -> tuple[float, float]:
        """Convert raw input into a facing-relative 2D world direction."""
        if input_state.move_x == 0.0 and input_state.move_y == 0.0:
            return 0.0, 0.0

        length = math.hypot(facing_x, facing_y)
        if length <= 0.0001:
            forward_x, forward_y = 0.0, -1.0
        else:
            forward_x = facing_x / length
            forward_y = facing_y / length
        right_x, right_y = -forward_y, forward_x
        desired_x = right_x * input_state.move_x + forward_x * (-input_state.move_y)
        desired_y = right_y * input_state.move_x + forward_y * (-input_state.move_y)
        desired_length = math.hypot(desired_x, desired_y)
        if desired_length <= 0.0001:
            return 0.0, 0.0
        return desired_x / desired_length, desired_y / desired_length

    def _update_velocity(self, direction_x: float, direction_y: float, frame_time: float) -> None:
        """Move current velocity toward requested camera-relative movement."""
        movement_config = self._config.render3d.player_movement
        tile_size_px = self._runtime_map.tile_size_px
        max_speed = movement_config.movement_speed_tiles_per_second * tile_size_px
        current_x = self._velocity_x_px_per_second
        current_y = self._velocity_y_px_per_second
        target_x = direction_x * max_speed
        target_y = direction_y * max_speed
        if direction_x == 0.0 and direction_y == 0.0:
            max_delta = (
                movement_config.deceleration_tiles_per_second_squared
                * tile_size_px
                * frame_time
            )
        else:
            max_delta = (
                movement_config.acceleration_tiles_per_second_squared
                * tile_size_px
                * frame_time
            )
        self._velocity_x_px_per_second, self._velocity_y_px_per_second = self._move_vector_toward(
            current_x=current_x,
            current_y=current_y,
            target_x=target_x,
            target_y=target_y,
            max_delta=max_delta,
        )

    def _update_player_aim(self, player: PlayerState) -> None:
        """Update the runtime aim state from smoothed visual facing."""
        aim_target = WorldCoord(
            x=player.world_position.x + self._last_facing_x * self._runtime_map.tile_size_px,
            y=player.world_position.y + self._last_facing_y * self._runtime_map.tile_size_px,
        )
        player.aim = PlayerAimState.from_positions(player.world_position, aim_target)

    def _player_speed_px_per_second(self) -> float:
        """Return current experimental player movement speed in pixels per second."""
        return math.hypot(
            self._velocity_x_px_per_second,
            self._velocity_y_px_per_second,
        )

    def _update_camera_relative_basis(self, camera_state: object) -> None:
        """Refresh the movement basis from the current 3D camera view."""
        direction_x = camera_state.target.x - camera_state.position.x
        direction_y = camera_state.target.z - camera_state.position.z
        length = math.hypot(direction_x, direction_y)
        if length <= 0.0001:
            return
        self._camera_forward_x = direction_x / length
        self._camera_forward_y = direction_y / length

    @staticmethod
    def _move_vector_toward(
        current_x: float,
        current_y: float,
        target_x: float,
        target_y: float,
        max_delta: float,
    ) -> tuple[float, float]:
        """Move a 2D vector toward another by a maximum distance."""
        delta_x = target_x - current_x
        delta_y = target_y - current_y
        delta_length = math.hypot(delta_x, delta_y)
        if delta_length <= max_delta or delta_length <= 0.0001:
            return target_x, target_y
        ratio = max_delta / delta_length
        return current_x + delta_x * ratio, current_y + delta_y * ratio

    def _draw_scene(self, scene: Render3DSceneSnapshot) -> None:
        """Draw visible map primitives.

        Args:
            scene: Visible 3D scene snapshot.
        """
        raylib = self._raylib
        tile_size = self._config.render3d.tile_size
        height_scale = self._config.render3d.height_scale
        ground_y = -0.03 * height_scale
        ground_width = (scene.max_x - scene.min_x + 1) * tile_size
        ground_depth = (scene.max_y - scene.min_y + 1) * tile_size
        ground_center_x = (scene.min_x + scene.max_x + 1) * 0.5 * tile_size
        ground_center_z = (scene.min_y + scene.max_y + 1) * 0.5 * tile_size
        raylib.draw_cube(
            raylib.Vector3(ground_center_x, ground_y, ground_center_z),
            ground_width,
            0.04 * height_scale,
            ground_depth,
            self._scene_color(raylib.DARKGREEN, ground_center_x, ground_center_z, scene),
        )
        for primitive in scene.primitives:
            center_x = (primitive.x + 0.5) * tile_size
            center_z = (primitive.y + 0.5) * tile_size
            center = raylib.Vector3(center_x, 0.0, center_z)
            color = self._scene_color_for_primitive(
                self._tile_color(primitive.symbol),
                primitive,
            )
            draw_detail = self._should_draw_environment_detail(primitive)
            if primitive.walkable:
                self._draw_walkable_tile(
                    center,
                    primitive.symbol,
                    color,
                    draw_detail=draw_detail,
                )
                continue
            self._draw_blocking_tile(
                center,
                primitive.symbol,
                color,
                draw_detail=draw_detail,
            )
        self._draw_runtime_objects(scene)

    def _draw_runtime_objects(self, scene: Render3DSceneSnapshot) -> None:
        """Draw readable runtime object primitives in the 3D gameplay scene."""
        raylib = self._raylib
        tile_size = self._config.render3d.tile_size
        height_scale = self._config.render3d.height_scale
        consumed_ids = (
            self._interaction_system.consumed_object_ids
            | self._explosion_system.destroyed_object_ids
        )
        for map_object in scene.runtime_objects:
            base_color = self._runtime_object_color(
                map_object,
                consumed=map_object.object_id in consumed_ids,
            )
            color = self._scene_color(
                base_color,
                (map_object.origin.x + 0.5) * tile_size,
                (map_object.origin.y + 0.5) * tile_size,
                scene,
            )
            width = tile_size * self._runtime_object_width_scale(map_object)
            depth = tile_size * self._runtime_object_depth_scale(map_object)
            height = tile_size * self._runtime_object_height_scale(map_object) * height_scale
            if map_object.object_type == "trench":
                height = 0.025 * height_scale
            for tile in map_object.footprint:
                if tile.x < scene.min_x or tile.x > scene.max_x:
                    continue
                if tile.y < scene.min_y or tile.y > scene.max_y:
                    continue
                center = raylib.Vector3(
                    (tile.x + 0.5) * tile_size,
                    height * 0.5,
                    (tile.y + 0.5) * tile_size,
                )
                self._draw_runtime_object_primitive(
                    center=center,
                    width=width,
                    height=max(0.01, height),
                    depth=depth,
                    color=color,
                    map_object=map_object,
                )
                if tile == map_object.origin:
                    self._draw_runtime_object_marker(
                        center=center,
                        width=width,
                        height=max(0.01, height),
                        depth=depth,
                        map_object=map_object,
                        consumed=map_object.object_id in consumed_ids,
                        scene=scene,
                    )

    def _draw_runtime_object_primitive(
        self,
        *,
        center: object,
        width: float,
        height: float,
        depth: float,
        color: object,
        map_object: RuntimeMapObject,
    ) -> None:
        """Draw a 3D primitive for one runtime object footprint tile."""
        raylib = self._raylib
        if map_object.object_type in {"rusted_barrel", "big_dead_tree", "broken_radio_mast"}:
            radius = max(0.04, min(width, depth) * 0.5)
            if hasattr(raylib, "draw_cylinder"):
                raylib.draw_cylinder(center, radius, radius, height, 10, color)
                return
        raylib.draw_cube(center, width, height, depth, color)
        if map_object.object_type == "scrap_pile":
            detail_color = self._runtime_object_marker_color("scrap_pile", consumed=False)
            detail_center = raylib.Vector3(center.x + width * 0.18, center.y + height * 0.55, center.z)
            raylib.draw_cube(detail_center, width * 0.35, height * 0.45, depth * 0.35, detail_color)

    def _draw_runtime_object_marker(
        self,
        *,
        center: object,
        width: float,
        height: float,
        depth: float,
        map_object: RuntimeMapObject,
        consumed: bool,
        scene: Render3DSceneSnapshot,
    ) -> None:
        """Draw semantic 3D markers only for interaction-critical objects."""
        object_type = map_object.object_type
        if object_type not in {"ammo_cache", "medkit_cache", "rusted_barrel"}:
            return
        raylib = self._raylib
        marker_color = self._scene_color(
            self._runtime_object_marker_color(object_type, consumed=consumed),
            center.x,
            center.z,
            scene,
        )
        marker_y = center.y + height * 0.65 + max(width, depth) * 0.12
        if object_type == "medkit_cache":
            self._draw_3d_cross_marker(center.x, marker_y, center.z, max(width, depth), marker_color)
            return
        if object_type == "ammo_cache":
            self._draw_3d_ammo_marker(center.x, marker_y, center.z, max(width, depth), marker_color)
            return
        self._draw_3d_warning_marker(center.x, marker_y, center.z, max(width, depth), marker_color)

    def _draw_3d_cross_marker(
        self,
        x: float,
        y: float,
        z: float,
        size: float,
        color: object,
    ) -> None:
        """Draw a small 3D medical cross marker."""
        raylib = self._raylib
        bar = max(0.04, size * 0.16)
        length = max(bar, size * 0.48)
        center = raylib.Vector3(x, y, z)
        raylib.draw_cube(center, bar, bar, length, color)
        raylib.draw_cube(center, length, bar, bar, color)

    def _draw_3d_ammo_marker(
        self,
        x: float,
        y: float,
        z: float,
        size: float,
        color: object,
    ) -> None:
        """Draw three short ammo ticks above an ammo cache."""
        raylib = self._raylib
        tick_width = max(0.035, size * 0.08)
        tick_height = max(0.07, size * 0.32)
        gap = max(0.035, size * 0.12)
        for index in (-1, 0, 1):
            center = raylib.Vector3(x + index * gap, y + tick_height * 0.5, z)
            raylib.draw_cube(center, tick_width, tick_height, tick_width, color)

    def _draw_3d_warning_marker(
        self,
        x: float,
        y: float,
        z: float,
        size: float,
        color: object,
    ) -> None:
        """Draw a compact warning marker above a hazardous object."""
        raylib = self._raylib
        stem_width = max(0.035, size * 0.08)
        stem_height = max(0.08, size * 0.34)
        stem_center = raylib.Vector3(x, y + stem_height * 0.5, z)
        dot_center = raylib.Vector3(x, y - stem_height * 0.18, z)
        raylib.draw_cube(stem_center, stem_width, stem_height, stem_width, color)
        raylib.draw_cube(dot_center, stem_width * 1.45, stem_width * 1.45, stem_width * 1.45, color)

    def _runtime_object_width_scale(self, map_object: RuntimeMapObject) -> float:
        """Return placeholder width scale for a runtime object."""
        if map_object.object_type == "fallen_log":
            return 0.88 if self._runtime_object_footprint_is_horizontal(map_object) else 0.34
        if map_object.object_type == "trench":
            return 0.96
        if map_object.object_type in {"ammo_cache", "medkit_cache"}:
            return 0.46
        if map_object.object_type in {"big_dead_tree", "broken_radio_mast", "rusted_barrel"}:
            return 0.36
        if map_object.object_type == "old_checkpoint":
            return 0.86
        if map_object.object_type == "scrap_pile":
            return 0.72
        if map_object.cover_type in {"soft", "partial"}:
            return 0.68
        return 0.72

    def _runtime_object_depth_scale(self, map_object: RuntimeMapObject) -> float:
        """Return placeholder depth scale for a runtime object."""
        if map_object.object_type == "fallen_log":
            return 0.34 if self._runtime_object_footprint_is_horizontal(map_object) else 0.88
        if map_object.object_type == "trench":
            return 0.96
        if map_object.object_type in {"ammo_cache", "medkit_cache"}:
            return 0.46
        if map_object.object_type in {"big_dead_tree", "broken_radio_mast", "rusted_barrel"}:
            return 0.36
        if map_object.object_type == "old_checkpoint":
            return 0.86
        if map_object.object_type == "scrap_pile":
            return 0.72
        if map_object.cover_type in {"soft", "partial"}:
            return 0.68
        return 0.72

    def _runtime_object_footprint_is_horizontal(self, map_object: RuntimeMapObject) -> bool:
        """Return whether a runtime object footprint is wider than it is tall."""
        xs = {tile.x for tile in map_object.footprint}
        ys = {tile.y for tile in map_object.footprint}
        return len(xs) >= len(ys)

    def _runtime_object_height_scale(self, map_object: RuntimeMapObject) -> float:
        """Return placeholder height scale for a runtime object."""
        if map_object.object_type == "trench":
            return 0.02
        if map_object.object_type in {"ammo_cache", "medkit_cache"}:
            return 0.22
        if map_object.object_type == "fallen_log":
            return 0.26
        if map_object.object_type == "rusted_barrel":
            return 0.66
        if map_object.object_type == "broken_radio_mast":
            return max(1.35, float(map_object.height) * 0.48)
        if map_object.object_type == "big_dead_tree":
            return max(1.2, float(map_object.height) * 0.42)
        if map_object.object_type == "old_checkpoint":
            return max(0.72, float(map_object.height) * 0.32)
        if map_object.cover_type == "soft":
            return 0.35
        if map_object.cover_type == "partial":
            return 0.45
        return max(0.25, min(0.9, float(map_object.height) * 0.25))

    def _runtime_object_color(
        self,
        map_object: RuntimeMapObject,
        *,
        consumed: bool = False,
    ) -> object:
        """Return a stable 3D placeholder color for a runtime object."""
        raylib = self._raylib
        if consumed:
            return raylib.Color(58, 58, 58, 135)
        if map_object.object_type == "ammo_cache":
            return raylib.Color(78, 88, 54, 245)
        if map_object.object_type == "medkit_cache":
            return raylib.Color(230, 230, 218, 245)
        if map_object.object_type == "trench":
            return raylib.Color(64, 45, 32, 235)
        if map_object.cover_type == "soft" or map_object.object_type == "bush_thicket":
            return raylib.Color(43, 132, 61, 220)
        if map_object.object_type == "fallen_log":
            return raylib.Color(121, 77, 41, 240)
        if map_object.object_type == "stone_chunk":
            return raylib.Color(130, 130, 130, 240)
        if map_object.object_type == "scrap_pile":
            return raylib.Color(92, 98, 108, 240)
        if map_object.object_type == "rusted_barrel":
            return raylib.Color(144, 84, 42, 235)
        if map_object.object_type == "old_checkpoint":
            return raylib.Color(96, 96, 92, 245)
        if map_object.role in {"landmark", "defensive_landmark"}:
            return raylib.Color(126, 91, 60, 240)
        return raylib.Color(118, 118, 118, 235)

    def _runtime_object_marker_color(self, object_type: str, *, consumed: bool) -> object:
        """Return a marker color for 3D semantic icons."""
        raylib = self._raylib
        alpha = 120 if consumed else 245
        if object_type == "medkit_cache":
            return raylib.Color(225, 35, 45, alpha)
        if object_type == "ammo_cache":
            return raylib.Color(255, 224, 80, alpha)
        if object_type == "rusted_barrel":
            return raylib.Color(255, 196, 70, alpha)
        return raylib.Color(165, 170, 178, alpha)

    def _draw_walkable_tile(
        self,
        center: object,
        symbol: str,
        color: object,
        *,
        draw_detail: bool,
    ) -> None:
        """Draw one walkable gameplay tile with symbol-specific readability."""
        raylib = self._raylib
        tile_size = self._config.render3d.tile_size
        height_scale = self._config.render3d.height_scale
        if symbol in {"+", "f", "m", "b"}:
            tile_height = 0.07 * height_scale
        elif symbol == "w":
            tile_height = 0.025 * height_scale
        else:
            tile_height = 0.04 * height_scale
        tile_center = raylib.Vector3(center.x, tile_height * 0.5, center.z)
        raylib.draw_cube(tile_center, tile_size, tile_height, tile_size, color)
        if not draw_detail:
            return
        if symbol == "w":
            self._draw_tile_surface_outline(tile_center, tile_size, tile_height, raylib.BLUE)
        elif symbol in {"S", "G", "R"}:
            self._draw_tile_surface_outline(tile_center, tile_size, tile_height, raylib.RAYWHITE)

    def _draw_blocking_tile(
        self,
        center: object,
        symbol: str,
        color: object,
        *,
        draw_detail: bool,
    ) -> None:
        """Draw one blocking map tile with stronger environment silhouettes."""
        raylib = self._raylib
        tile_size = self._config.render3d.tile_size
        height_scale = self._config.render3d.height_scale
        if symbol == "T" and draw_detail:
            trunk_height = 0.82 * height_scale
            canopy_height = 0.62 * height_scale
            trunk_center = raylib.Vector3(center.x, trunk_height * 0.5, center.z)
            canopy_center = raylib.Vector3(
                center.x,
                trunk_height + canopy_height * 0.35,
                center.z,
            )
            raylib.draw_cube(
                trunk_center,
                tile_size * 0.34,
                trunk_height,
                tile_size * 0.34,
                color,
            )
            raylib.draw_cube(
                canopy_center,
                tile_size * 0.94,
                canopy_height,
                tile_size * 0.94,
                self._scene_green_shadow(color),
            )
            return

        height = self._blocking_tile_height(symbol) * height_scale
        width = tile_size * self._blocking_tile_width_scale(symbol)
        block_center = raylib.Vector3(center.x, height * 0.5, center.z)
        raylib.draw_cube(block_center, width, height, width, color)
        if draw_detail:
            self._draw_tile_surface_outline(block_center, width, height, raylib.RAYWHITE)

    def _should_draw_environment_detail(self, primitive: Render3DTilePrimitive) -> bool:
        """Return whether an environment primitive is close enough for extra draw calls."""
        detail_radius = self._ENVIRONMENT_DETAIL_RADIUS_TILES
        return primitive.distance_squared <= detail_radius * detail_radius

    def _blocking_tile_height(self, symbol: str) -> float:
        """Return 3D height in tiles for a blocking symbol."""
        if symbol == "#":
            return 1.35
        if symbol in {"c", "b"}:
            return 0.55
        return 0.9

    def _blocking_tile_width_scale(self, symbol: str) -> float:
        """Return width multiplier for a blocking symbol."""
        if symbol in {"c", "b"}:
            return 0.78
        return 1.0

    def _draw_tile_surface_outline(
        self,
        center: object,
        width: float,
        height: float,
        color: object,
    ) -> None:
        """Draw a subtle wire outline around an environment tile."""
        draw_cube_wires = getattr(self._raylib, "draw_cube_wires", None)
        if callable(draw_cube_wires):
            draw_cube_wires(center, width, height, width, self._color_with_alpha(color, 95))

    def _scene_green_shadow(self, color: object) -> object:
        """Return a darker green-ish variation for tree canopies."""
        raylib = self._raylib
        try:
            return raylib.Color(
                max(0, min(255, int(color.r) - 18)),
                max(0, min(255, int(color.g) + 18)),
                max(0, min(255, int(color.b) - 12)),
                int(getattr(color, "a", 255)),
            )
        except AttributeError:
            return color

    def _scene_color_for_primitive(
        self,
        color: object,
        primitive: Render3DTilePrimitive,
    ) -> object:
        """Return a distance-faded color for a pre-culled tile primitive."""
        brightness = self._distance_brightness_for_tile_distance_squared(
            primitive.distance_squared,
        )
        if brightness >= 0.999:
            return color
        return self._scale_color(color, brightness)

    def _distance_brightness_for_tile_distance_squared(
        self,
        distance_squared: int,
    ) -> float:
        """Return distance fade brightness from squared tile distance."""
        fade_config = self._config.render3d.distance_fade
        if not self._distance_fade_enabled:
            return 1.0
        radius = self._config.render3d.view_radius_tiles
        if radius <= 0:
            return 1.0
        start = radius * fade_config.fade_start_ratio
        start_squared = start * start
        if float(distance_squared) <= start_squared:
            return 1.0
        distance = math.sqrt(float(distance_squared))
        fade_range = max(float(radius) - start, 0.0001)
        progress = max(0.0, min(1.0, (distance - start) / fade_range))
        fog_amount = progress ** fade_config.fog_density
        return 1.0 - (1.0 - fade_config.min_brightness) * fog_amount

    def _scene_color(
        self,
        color: object,
        x: float,
        z: float,
        scene: Render3DSceneSnapshot,
    ) -> object:
        """Return a distance-faded scene color for a 3D position."""
        brightness = self._distance_brightness_for_scene_position(x=x, z=z, scene=scene)
        if brightness >= 0.999:
            return color
        return self._scale_color(color, brightness)

    def _distance_brightness_for_scene_position(
        self,
        x: float,
        z: float,
        scene: Render3DSceneSnapshot,
    ) -> float:
        """Return brightness for a scene position based on player-centered radius."""
        fade_config = self._config.render3d.distance_fade
        if not self._distance_fade_enabled:
            return 1.0
        tile_size = self._config.render3d.tile_size
        center_x = (scene.center_tile.x + 0.5) * tile_size
        center_z = (scene.center_tile.y + 0.5) * tile_size
        radius = self._config.render3d.view_radius_tiles * tile_size
        if radius <= 0.0001:
            return 1.0
        distance = math.hypot(x - center_x, z - center_z)
        start = radius * fade_config.fade_start_ratio
        if distance <= start:
            return 1.0
        fade_range = max(radius - start, 0.0001)
        progress = max(0.0, min(1.0, (distance - start) / fade_range))
        fog_amount = progress ** fade_config.fog_density
        return 1.0 - (1.0 - fade_config.min_brightness) * fog_amount

    def _scale_color(self, color: object, brightness: float) -> object:
        """Scale an RGB raylib color by brightness while keeping alpha."""
        raylib = self._raylib
        try:
            red = int(max(0, min(255, float(color.r) * brightness)))
            green = int(max(0, min(255, float(color.g) * brightness)))
            blue = int(max(0, min(255, float(color.b) * brightness)))
            alpha = int(getattr(color, "a", 255))
        except AttributeError:
            return color
        return raylib.Color(red, green, blue, alpha)


    def _visible_enemies(
        self,
        enemies: tuple[EnemyState, ...],
        player_position: WorldCoord,
    ) -> tuple[EnemyState, ...]:
        """Return alive enemies inside the player-centered 3D view radius.

        Args:
            enemies: Runtime enemies spawned from tactical map data.
            player_position: Current player position in world pixels.

        Returns:
            Distance-sorted tuple of enemies visible in the 3D experiment.
        """
        enemy_config = self._config.render3d.enemies
        if not enemy_config.draw_enemy_markers:
            return ()

        radius_px = self._config.render3d.view_radius_tiles * self._runtime_map.tile_size_px
        radius_squared = radius_px * radius_px
        candidates: list[tuple[float, EnemyState]] = []
        for enemy in enemies:
            if not enemy.alive:
                continue
            dx = enemy.world_position.x - player_position.x
            dy = enemy.world_position.y - player_position.y
            distance_squared = dx * dx + dy * dy
            if distance_squared <= radius_squared:
                candidates.append((distance_squared, enemy))

        candidates.sort(key=lambda item: item[0])
        return tuple(
            enemy
            for _, enemy in candidates[: enemy_config.max_visible_enemies]
        )

    def _draw_enemy_vision_cones(self, enemies: tuple[EnemyState, ...]) -> None:
        """Draw gameplay enemy vision cones from the existing perception config.

        Args:
            enemies: Visible enemies whose runtime vision cones should be drawn.
        """
        vision_config = self._config.render3d.enemy_vision
        if not self._enemy_vision_enabled or not enemies:
            return

        raylib = self._raylib
        render_config = self._config.render3d
        tile_size = render_config.tile_size
        height_scale = render_config.height_scale
        tile_size_px = self._runtime_map.tile_size_px
        cone_range = (
            self._config.enemies.vision_range_px
            / tile_size_px
            * tile_size
            * vision_config.range_scale
        )
        half_angle = math.radians(self._config.enemies.vision_angle_degrees) * 0.5
        segments = max(2, vision_config.cone_segments)
        cone_y = vision_config.height_tiles * height_scale

        for enemy in enemies[: vision_config.max_visible_cones]:
            origin = raylib.Vector3(
                enemy.world_position.x / tile_size_px * tile_size,
                cone_y,
                enemy.world_position.y / tile_size_px * tile_size,
            )
            facing = math.radians(enemy.facing_angle_degrees)
            color = self._enemy_vision_color(enemy)
            previous_point = None
            for index in range(segments + 1):
                ratio = index / segments
                angle = facing - half_angle + ratio * half_angle * 2.0
                point = raylib.Vector3(
                    origin.x + math.cos(angle) * cone_range,
                    cone_y,
                    origin.z + math.sin(angle) * cone_range,
                )
                if index in {0, segments}:
                    raylib.draw_line_3d(origin, point, color)
                if previous_point is not None:
                    raylib.draw_line_3d(previous_point, point, color)
                previous_point = point

    def _enemy_vision_color(self, enemy: EnemyState) -> object:
        """Return enemy vision cone color based on runtime awareness state."""
        vision_config = self._config.render3d.enemy_vision
        if enemy.awareness_state == "engaged":
            alpha = vision_config.combat_alpha
            base_color = self._raylib.RED
        elif enemy.alerted or enemy.awareness_state in {"searching", "returning"}:
            alpha = vision_config.alert_alpha
            base_color = self._raylib.ORANGE
        else:
            alpha = vision_config.idle_alpha
            base_color = self._raylib.YELLOW
        return self._color_with_alpha(base_color, alpha)

    def _color_with_alpha(self, color: object, alpha: int) -> object:
        """Return a raylib color with the requested alpha channel."""
        raylib = self._raylib
        try:
            return raylib.Color(
                int(color.r),
                int(color.g),
                int(color.b),
                max(0, min(255, int(alpha))),
            )
        except AttributeError:
            return color

    def _draw_enemy_markers(self, enemies: tuple[EnemyState, ...]) -> None:
        """Draw visible enemies with state-readable 3D gameplay markers.

        Args:
            enemies: Visible enemies to draw.
        """
        if not enemies:
            return

        raylib = self._raylib
        render_config = self._config.render3d
        enemy_config = render_config.enemies
        tile_size = render_config.tile_size
        height_scale = render_config.height_scale
        tile_size_px = self._runtime_map.tile_size_px
        marker_radius = enemy_config.marker_radius_tiles * tile_size
        marker_height = enemy_config.marker_height_tiles * height_scale
        direction_length = enemy_config.direction_line_length_tiles * tile_size
        ring_radius = marker_radius * 1.55
        ring_height = 0.035 * height_scale
        facing_y = marker_height + marker_radius

        for enemy in enemies:
            center = raylib.Vector3(
                enemy.world_position.x / tile_size_px * tile_size,
                marker_height * 0.5,
                enemy.world_position.y / tile_size_px * tile_size,
            )
            color = self._enemy_marker_color(enemy)
            state_color = self._enemy_state_color(enemy)
            ring_center = raylib.Vector3(center.x, ring_height * 0.5, center.z)
            raylib.draw_cylinder_wires(
                ring_center,
                ring_radius,
                ring_radius,
                ring_height,
                20,
                state_color,
            )
            raylib.draw_cylinder(
                center,
                marker_radius,
                marker_radius * 0.85,
                marker_height,
                12,
                color,
            )
            head_center = raylib.Vector3(center.x, marker_height + marker_radius, center.z)
            raylib.draw_sphere(
                head_center,
                marker_radius * 0.85,
                color,
            )
            status_center = raylib.Vector3(
                center.x,
                marker_height + marker_radius * 2.2,
                center.z,
            )
            raylib.draw_sphere(
                status_center,
                marker_radius * 0.34,
                state_color,
            )
            if self._is_enemy_hit_flashing(enemy):
                raylib.draw_sphere(
                    head_center,
                    marker_radius * 1.25,
                    raylib.YELLOW,
                )
            facing_radians = math.radians(enemy.facing_angle_degrees)
            facing_start = raylib.Vector3(center.x, facing_y, center.z)
            direction_end = raylib.Vector3(
                center.x + math.cos(facing_radians) * direction_length,
                facing_y,
                center.z + math.sin(facing_radians) * direction_length,
            )
            raylib.draw_line_3d(facing_start, direction_end, state_color)
            raylib.draw_sphere(
                direction_end,
                marker_radius * 0.28,
                state_color,
            )


    def _visible_enemy_hit_markers(
        self,
        hit_markers: tuple[EnemyHitMarkerState, ...],
        player_position: WorldCoord,
    ) -> tuple[EnemyHitMarkerState, ...]:
        """Return visible enemy hit markers inside the player-centered radius.

        Args:
            hit_markers: Active enemy hit markers.
            player_position: Current player position in world pixels.

        Returns:
            Distance-sorted visible enemy hit markers.
        """
        combat_config = self._config.render3d.combat_visuals
        if not combat_config.draw_enemy_hit_markers:
            return ()
        candidates: list[tuple[float, EnemyHitMarkerState]] = []
        radius_squared = self._view_radius_px_squared()
        for marker in hit_markers:
            if not marker.alive:
                continue
            dx = marker.position.x - player_position.x
            dy = marker.position.y - player_position.y
            distance_squared = dx * dx + dy * dy
            if distance_squared <= radius_squared:
                candidates.append((distance_squared, marker))
        candidates.sort(key=lambda item: item[0])
        return tuple(
            marker
            for _, marker in candidates[: combat_config.max_visible_enemy_hit_markers]
        )

    def _visible_projectiles(
        self,
        projectiles: tuple[ProjectileState, ...],
        player_position: WorldCoord,
    ) -> tuple[ProjectileState, ...]:
        """Return visible active projectiles inside the player-centered radius.

        Args:
            projectiles: Active runtime projectiles.
            player_position: Current player position in world pixels.

        Returns:
            Distance-sorted visible projectiles.
        """
        projectile_config = self._config.render3d.projectiles
        if not projectile_config.draw_projectiles:
            return ()
        candidates: list[tuple[float, ProjectileState]] = []
        radius_squared = self._view_radius_px_squared()
        for projectile in projectiles:
            if not projectile.alive:
                continue
            dx = projectile.position.x - player_position.x
            dy = projectile.position.y - player_position.y
            distance_squared = dx * dx + dy * dy
            if distance_squared <= radius_squared:
                candidates.append((distance_squared, projectile))
        candidates.sort(key=lambda item: item[0])
        return tuple(
            projectile
            for _, projectile in candidates[: projectile_config.max_visible_projectiles]
        )

    def _visible_impacts(
        self,
        impacts: tuple[ImpactMarkerState, ...],
        player_position: WorldCoord,
    ) -> tuple[ImpactMarkerState, ...]:
        """Return visible impact markers inside the player-centered radius.

        Args:
            impacts: Active projectile impact markers.
            player_position: Current player position in world pixels.

        Returns:
            Distance-sorted visible impact markers.
        """
        projectile_config = self._config.render3d.projectiles
        if not projectile_config.draw_impacts:
            return ()
        candidates: list[tuple[float, ImpactMarkerState]] = []
        radius_squared = self._view_radius_px_squared()
        for impact in impacts:
            if not impact.alive:
                continue
            dx = impact.position.x - player_position.x
            dy = impact.position.y - player_position.y
            distance_squared = dx * dx + dy * dy
            if distance_squared <= radius_squared:
                candidates.append((distance_squared, impact))
        candidates.sort(key=lambda item: item[0])
        return tuple(impact for _, impact in candidates)

    def _draw_enemy_hit_markers(self, hit_markers: tuple[EnemyHitMarkerState, ...]) -> None:
        """Draw short-lived enemy hit feedback markers.

        Args:
            hit_markers: Visible enemy hit markers to draw.
        """
        if not hit_markers:
            return
        raylib = self._raylib
        render_config = self._config.render3d
        combat_config = render_config.combat_visuals
        tile_size = render_config.tile_size
        height_scale = render_config.height_scale
        tile_size_px = self._runtime_map.tile_size_px
        marker_y = combat_config.enemy_hit_marker_height_tiles * height_scale
        base_radius = combat_config.enemy_hit_marker_radius_tiles * tile_size
        for marker in hit_markers:
            progress = self._age_progress(marker.age_seconds, marker.lifetime_seconds)
            radius = base_radius * (1.0 + progress * 0.7)
            center = raylib.Vector3(
                marker.position.x / tile_size_px * tile_size,
                marker_y,
                marker.position.y / tile_size_px * tile_size,
            )
            raylib.draw_sphere(center, radius * 0.35, raylib.YELLOW)
            raylib.draw_cylinder_wires(
                center,
                radius,
                radius,
                0.05 * height_scale,
                18,
                raylib.GOLD,
            )

    def _apply_camera_feedback(
        self,
        camera_state: Render3DCameraState,
    ) -> Render3DCameraState:
        """Apply unsmoothed screen-punch camera feedback to a 3D camera state."""
        offset = self._camera_feedback.offset
        tile_size_px = self._runtime_map.tile_size_px
        if tile_size_px <= 0 or (abs(offset.x) <= 0.001 and abs(offset.y) <= 0.001):
            return camera_state
        offset_x = offset.x / tile_size_px
        offset_z = offset.y / tile_size_px
        return Render3DCameraState(
            position=Render3DVector(
                x=camera_state.position.x + offset_x,
                y=camera_state.position.y,
                z=camera_state.position.z + offset_z,
            ),
            target=Render3DVector(
                x=camera_state.target.x + offset_x,
                y=camera_state.target.y,
                z=camera_state.target.z + offset_z,
            ),
        )

    def _add_projectile_events(self, events: tuple[ProjectileEvent, ...]) -> None:
        """Add projectile feedback events used by short-lived 3D visuals."""
        for event in events:
            if event.event_type != ProjectileEventType.SPAWNED:
                continue
            self._muzzle_flashes.append(
                _Render3DMuzzleFlashState(
                    position=event.position,
                    owner=event.owner,
                    visual_profile=event.visual_profile,
                    lifetime_seconds=self._muzzle_flash_lifetime(event.visual_profile),
                ),
            )
            self._spawn_shell_casing(event)

    def _update_muzzle_flashes(self, frame_time: float) -> None:
        """Advance active 3D muzzle flashes."""
        if frame_time <= 0.0:
            return
        for flash in self._muzzle_flashes:
            flash.age_seconds += frame_time
        self._muzzle_flashes = [
            flash
            for flash in self._muzzle_flashes
            if flash.age_seconds < flash.lifetime_seconds
        ]

    def _spawn_shell_casing(self, event: ProjectileEvent) -> None:
        """Create one 3D shell casing for one spawned shot event."""
        shell_config = self._config.shell_ejection
        if not shell_config.enabled:
            return
        direction_length = math.hypot(event.direction_x, event.direction_y)
        if direction_length <= 0.0001:
            return
        direction_x = event.direction_x / direction_length
        direction_y = event.direction_y / direction_length
        right_x, right_y = self._rotated_right_normal(
            direction_x,
            direction_y,
            self._shell_spread_offset_degrees(self._shell_sequence),
        )
        size = self._shell_size(self._shell_sequence, event.visual_profile)
        travel = (
            shell_config.ejection_distance_px
            * shell_config.ejection_intensity
            * self._shell_profile_distance_scale(event.visual_profile)
            * self._sequence_unit(self._shell_sequence, salt=17, min_value=0.72, max_value=1.15)
        )
        self._shell_casings.append(
            _Render3DShellCasingState(
                origin=WorldCoord(
                    event.position.x + right_x * max(2.0, size),
                    event.position.y + right_y * max(2.0, size),
                ),
                direction_x=right_x,
                direction_y=right_y,
                size_px=size,
                travel_distance_px=travel,
                owner=event.owner,
                visual_profile=event.visual_profile,
                lifetime_seconds=self._shell_lifetime(
                    self._shell_sequence,
                    event.visual_profile,
                ),
            ),
        )
        self._shell_sequence += 1
        overflow = len(self._shell_casings) - shell_config.max_active_shells
        if overflow > 0:
            del self._shell_casings[:overflow]

    def _update_shell_casings(self, frame_time: float) -> None:
        """Advance visible shell casings."""
        if frame_time <= 0.0:
            return
        for shell in self._shell_casings:
            shell.age_seconds += frame_time
        self._shell_casings = [
            shell
            for shell in self._shell_casings
            if shell.age_seconds < shell.lifetime_seconds
        ]

    def _draw_shell_casings(self) -> None:
        """Draw shell casings in 3D without affecting gameplay."""
        if not self._shell_casings:
            return
        raylib = self._raylib
        render_config = self._config.render3d
        tile_size = render_config.tile_size
        height_scale = render_config.height_scale
        tile_size_px = self._runtime_map.tile_size_px
        base_y = render_config.projectiles.projectile_height_tiles * height_scale * 0.38
        for shell in self._shell_casings:
            progress = self._age_progress(shell.age_seconds, shell.lifetime_seconds)
            alpha = int(220 * max(0.0, 1.0 - progress))
            if alpha <= 0:
                continue
            travel_curve = min(1.0, progress * 1.65)
            settle = travel_curve * (2.0 - travel_curve)
            world_x = shell.origin.x + shell.direction_x * shell.travel_distance_px * settle
            world_y = shell.origin.y + shell.direction_y * shell.travel_distance_px * settle
            center = raylib.Vector3(
                world_x / tile_size_px * tile_size,
                base_y,
                world_y / tile_size_px * tile_size,
            )
            size = max(0.035 * tile_size, shell.size_px / tile_size_px * tile_size)
            color = raylib.Color(204, 154, 62, alpha)
            raylib.draw_cube(center, size * 1.8, size * 0.35, size * 0.55, color)

    def _shell_size(self, sequence: int, visual_profile: str) -> float:
        """Return deterministic shell size for one 3D casing."""
        config = self._config.shell_ejection
        size = self._sequence_unit(
            sequence,
            salt=3,
            min_value=config.shell_size_min_px,
            max_value=config.shell_size_max_px,
        )
        if visual_profile == "minigun":
            return max(1.0, size * 0.78)
        if visual_profile == "ak47":
            return size * 1.08
        return size

    def _shell_lifetime(self, sequence: int, visual_profile: str) -> float:
        """Return deterministic shell lifetime for one 3D casing."""
        config = self._config.shell_ejection
        lifetime = self._sequence_unit(
            sequence,
            salt=11,
            min_value=config.lifetime_min_seconds,
            max_value=config.lifetime_max_seconds,
        )
        if visual_profile == "minigun":
            return max(config.lifetime_min_seconds, lifetime * 0.82)
        return lifetime

    def _shell_spread_offset_degrees(self, sequence: int) -> float:
        """Return deterministic shell ejection spread angle."""
        half_spread = self._config.shell_ejection.spread_degrees / 2.0
        return self._sequence_unit(
            sequence,
            salt=23,
            min_value=-half_spread,
            max_value=half_spread,
        )

    @staticmethod
    def _shell_profile_distance_scale(visual_profile: str) -> float:
        """Return shell travel scale for a weapon visual profile."""
        if visual_profile == "minigun":
            return 0.78
        if visual_profile == "ak47":
            return 1.08
        return 1.0

    @staticmethod
    def _rotated_right_normal(
        direction_x: float,
        direction_y: float,
        offset_degrees: float,
    ) -> tuple[float, float]:
        """Return right-side ejection normal rotated by a spread offset."""
        right_x = -direction_y
        right_y = direction_x
        angle = math.atan2(right_y, right_x) + math.radians(offset_degrees)
        return math.cos(angle), math.sin(angle)

    @staticmethod
    def _sequence_unit(
        sequence: int,
        *,
        salt: int,
        min_value: float,
        max_value: float,
    ) -> float:
        """Return a deterministic pseudo-random value in a closed range."""
        hashed = (sequence * 1103515245 + 12345 + salt * 2654435761) & 0x7FFFFFFF
        unit = float(hashed % 10000) / 9999.0
        return min_value + (max_value - min_value) * unit

    def _draw_muzzle_flashes(self) -> None:
        """Draw short-lived muzzle flashes in 3D space."""
        if not self._muzzle_flashes:
            return
        raylib = self._raylib
        render_config = self._config.render3d
        tile_size = render_config.tile_size
        height_scale = render_config.height_scale
        tile_size_px = self._runtime_map.tile_size_px
        y = render_config.projectiles.projectile_height_tiles * height_scale
        for flash in self._muzzle_flashes:
            progress = min(1.0, max(0.0, flash.age_seconds / flash.lifetime_seconds))
            radius = max(
                0.035 * tile_size,
                self._muzzle_flash_radius_tiles(
                    flash.visual_profile,
                    flash.owner,
                ) * tile_size * (1.0 - progress),
            )
            center = raylib.Vector3(
                flash.position.x / tile_size_px * tile_size,
                y,
                flash.position.y / tile_size_px * tile_size,
            )
            raylib.draw_sphere(center, radius, self._muzzle_flash_core_color(flash.owner))
            raylib.draw_cylinder_wires(
                center,
                radius * 1.8,
                radius * 1.8,
                0.03 * height_scale,
                12,
                self._muzzle_flash_ring_color(flash.owner, flash.visual_profile),
            )

    def _muzzle_flash_core_color(self, owner: ProjectileOwner) -> object:
        """Return 3D muzzle flash core color for a projectile owner."""
        if owner == ProjectileOwner.ENEMY:
            return self._raylib.ORANGE
        return self._raylib.YELLOW

    def _muzzle_flash_ring_color(
        self,
        owner: ProjectileOwner,
        visual_profile: str,
    ) -> object:
        """Return 3D muzzle flash ring color for an owner/profile."""
        profile = self._normalize_visual_profile(visual_profile, owner)
        if profile == "ak47":
            return self._raylib.ORANGE
        if profile == "minigun":
            return self._raylib.YELLOW
        if owner == ProjectileOwner.ENEMY:
            return self._raylib.RED
        return self._raylib.GOLD

    def _muzzle_flash_radius_tiles(
        self,
        visual_profile: str,
        owner: ProjectileOwner,
    ) -> float:
        """Return 3D muzzle flash radius in tile units for an owner/profile."""
        profile = self._normalize_visual_profile(visual_profile, owner)
        if profile == "minigun":
            return 0.12
        if profile == "ak47":
            return 0.22
        if profile == "enemy":
            return 0.20
        return 0.18

    def _muzzle_flash_lifetime(self, visual_profile: str) -> float:
        """Return 3D muzzle flash lifetime for the visual profile."""
        profile = visual_profile.strip().lower()
        if profile == "minigun":
            return 0.045
        if profile == "ak47":
            return 0.07
        return 0.09

    def _draw_projectile_markers(self, projectiles: tuple[ProjectileState, ...]) -> None:
        """Draw active projectiles as real previous-to-current 3D tracer markers.

        Args:
            projectiles: Visible projectiles to draw.
        """
        raylib = self._raylib
        render_config = self._config.render3d
        projectile_config = render_config.projectiles
        tile_size = render_config.tile_size
        height_scale = render_config.height_scale
        projectile_y = projectile_config.projectile_height_tiles * height_scale
        trail_y_offset = (
            render_config.combat_visuals.projectile_tracer_height_offset_tiles * height_scale
        )
        radius = projectile_config.projectile_radius_tiles * tile_size
        self._add_projectile_trails(projectiles)
        self._draw_projectile_trails(projectile_y + trail_y_offset)

    def _add_projectile_trails(self, projectiles: tuple[ProjectileState, ...]) -> None:
        """Capture real previous-to-current projectile segments for short 3D trails."""
        for projectile in projectiles:
            if not projectile.alive:
                continue
            dx = projectile.position.x - projectile.previous_position.x
            dy = projectile.position.y - projectile.previous_position.y
            if dx * dx + dy * dy < 1.0:
                continue
            owner = self._normalize_projectile_owner(projectile.owner)
            key = (
                int(round(projectile.previous_position.x)),
                int(round(projectile.previous_position.y)),
                int(round(projectile.position.x)),
                int(round(projectile.position.y)),
                owner.value,
                projectile.visual_profile,
            )
            if key in self._projectile_trail_keys:
                continue
            self._projectile_trail_keys.add(key)
            trail_start = self._clip_projectile_trail_start(projectile)
            self._projectile_trails.append(
                _Render3DProjectileTrailState(
                    previous_position=trail_start,
                    position=projectile.position,
                    owner=owner,
                    visual_profile=projectile.visual_profile,
                    key=key,
                ),
            )

    def _clip_projectile_trail_start(self, projectile: ProjectileState) -> WorldCoord:
        """Return a shortened 3D tracer start to avoid full-ray laser lines."""
        dx = projectile.position.x - projectile.previous_position.x
        dy = projectile.position.y - projectile.previous_position.y
        distance = math.hypot(dx, dy)
        if distance <= 0.0001:
            return projectile.previous_position
        max_length_px = (
            self._config.render3d.combat_visuals.projectile_tracer_length_tiles
            * self._runtime_map.tile_size_px
        )
        if distance <= max_length_px:
            return projectile.previous_position
        ratio = max_length_px / distance
        return WorldCoord(
            x=projectile.position.x - dx * ratio,
            y=projectile.position.y - dy * ratio,
        )

    def _update_projectile_trails(self, frame_time: float) -> None:
        """Advance active short-lived 3D projectile trails."""
        if frame_time <= 0.0:
            return
        for trail in self._projectile_trails:
            trail.age_seconds += frame_time
        alive_trails = [
            trail
            for trail in self._projectile_trails
            if trail.age_seconds < trail.lifetime_seconds
        ]
        self._projectile_trail_keys = {trail.key for trail in alive_trails}
        self._projectile_trails = alive_trails

    def _draw_projectile_trails(self, projectile_y: float) -> None:
        """Draw fading 3D projectile afterimage segments."""
        raylib = self._raylib
        for trail in self._projectile_trails:
            progress = min(1.0, max(0.0, trail.age_seconds / trail.lifetime_seconds))
            alpha = int(
                self._projectile_trail_alpha(
                    trail.visual_profile,
                    trail.owner,
                ) * (1.0 - progress),
            )
            if alpha <= 0:
                continue
            start = self._world_to_projectile_vector(trail.previous_position, projectile_y)
            end = self._world_to_projectile_vector(trail.position, projectile_y)
            raylib.draw_line_3d(
                start,
                end,
                self._projectile_trail_color(trail.owner, alpha, trail.visual_profile),
            )

    def _world_to_projectile_vector(self, position: WorldCoord, y: float) -> object:
        """Convert a world pixel position to a 3D projectile vector."""
        render_config = self._config.render3d
        tile_size = render_config.tile_size
        tile_size_px = self._runtime_map.tile_size_px
        return self._raylib.Vector3(
            position.x / tile_size_px * tile_size,
            y,
            position.y / tile_size_px * tile_size,
        )

    def _projectile_tracer_color(
        self,
        owner: ProjectileOwner | str,
        visual_profile: str,
    ) -> object:
        """Return tracer color based on projectile owner/profile."""
        owner_tag = self._normalize_projectile_owner(owner)
        profile = self._normalize_visual_profile(visual_profile, owner_tag)
        if profile == "minigun":
            return self._raylib.YELLOW
        if profile == "ak47":
            return self._raylib.GOLD
        if owner_tag == ProjectileOwner.ENEMY:
            return self._raylib.ORANGE
        return self._raylib.SKYBLUE

    def _projectile_trail_color(
        self,
        owner: ProjectileOwner | str,
        alpha: int,
        visual_profile: str,
    ) -> object:
        """Return fading trail color based on projectile owner/profile."""
        owner_tag = self._normalize_projectile_owner(owner)
        profile = self._normalize_visual_profile(visual_profile, owner_tag)
        if profile == "minigun":
            return self._raylib.Color(255, 245, 160, alpha)
        if profile == "ak47":
            return self._raylib.Color(255, 190, 72, alpha)
        if owner_tag == ProjectileOwner.ENEMY:
            return self._raylib.Color(255, 96, 32, alpha)
        return self._raylib.Color(120, 216, 255, alpha)

    def _projectile_trail_alpha(
        self,
        visual_profile: str,
        owner: ProjectileOwner,
    ) -> int:
        """Return base 3D projectile trail alpha for an owner/profile."""
        profile = self._normalize_visual_profile(visual_profile, owner)
        if profile == "minigun":
            return 130
        if profile == "enemy":
            return 210
        return 180

    def _projectile_core_color(self, owner: ProjectileOwner | str) -> object:
        """Return projectile core color based on projectile owner."""
        if self._normalize_projectile_owner(owner) == ProjectileOwner.ENEMY:
            return self._raylib.RED
        return self._raylib.RAYWHITE

    @staticmethod
    def _normalize_visual_profile(visual_profile: str, owner: ProjectileOwner) -> str:
        """Return a stable visual profile fallback."""
        profile = visual_profile.strip().lower()
        if profile:
            return profile
        return owner.value

    @staticmethod
    def _normalize_projectile_owner(owner: ProjectileOwner | str) -> ProjectileOwner:
        """Return a known projectile owner for rendering fallback."""
        try:
            return ProjectileOwner(owner)
        except ValueError:
            return ProjectileOwner.PLAYER

    def _draw_impact_markers(self, impacts: tuple[ImpactMarkerState, ...]) -> None:
        """Draw projectile impact markers in the 3D experiment.

        Args:
            impacts: Visible impact markers to draw.
        """
        if not impacts:
            return
        raylib = self._raylib
        render_config = self._config.render3d
        projectile_config = render_config.projectiles
        tile_size = render_config.tile_size
        height_scale = render_config.height_scale
        tile_size_px = self._runtime_map.tile_size_px
        impact_y = projectile_config.impact_height_tiles * height_scale
        for impact in impacts:
            center = raylib.Vector3(
                impact.position.x / tile_size_px * tile_size,
                impact_y,
                impact.position.y / tile_size_px * tile_size,
            )
            material = self._normalize_surface_material(impact.surface_material)
            particle_config = self._impact_particle_config(material)
            particle_lifetime = max(0.0001, self._config.projectile_impacts.lifetime_seconds)
            particle_progress = self._age_progress(impact.age_seconds, particle_lifetime)
            flash_alpha = int(230 * max(0.0, 1.0 - particle_progress / 0.28))
            if impact.age_seconds <= particle_lifetime and flash_alpha > 0:
                flash_radius = max(0.05 * tile_size, impact.radius_px / tile_size_px * tile_size)
                raylib.draw_line_3d(
                    raylib.Vector3(center.x - flash_radius, center.y, center.z),
                    raylib.Vector3(center.x + flash_radius, center.y, center.z),
                    self._impact_color(material, flash_alpha),
                )
                raylib.draw_line_3d(
                    raylib.Vector3(center.x, center.y, center.z - flash_radius),
                    raylib.Vector3(center.x, center.y, center.z + flash_radius),
                    self._impact_color(material, flash_alpha),
                )
            debris_alpha = int(210 * max(0.0, 1.0 - particle_progress / 0.78))
            if impact.age_seconds <= particle_lifetime and debris_alpha > 0:
                self._draw_impact_particles_3d(
                    center=center,
                    material=material,
                    particle_config=particle_config,
                    progress=particle_progress,
                    alpha=debris_alpha,
                )
            if (
                particle_config.decal_enabled
                and impact.age_seconds <= particle_config.decal_lifetime_seconds
            ):
                decal_progress = self._age_progress(
                    impact.age_seconds,
                    particle_config.decal_lifetime_seconds,
                )
                decal_alpha = int(170 * max(0.25, 1.0 - decal_progress * 0.65))
                self._draw_impact_decal_3d(
                    center=center,
                    material=material,
                    particle_config=particle_config,
                    progress=decal_progress,
                    alpha=decal_alpha,
                )


    def _draw_impact_decal_3d(
        self,
        *,
        center: object,
        material: SurfaceMaterial,
        particle_config: object,
        progress: float,
        alpha: int,
    ) -> None:
        """Draw a small lingering hit mark on the impact plane."""
        if material == SurfaceMaterial.FOLIAGE or alpha <= 0:
            return
        raylib = self._raylib
        tile_size = self._config.render3d.tile_size
        tile_size_px = self._runtime_map.tile_size_px
        radius = max(
            0.025 * tile_size,
            particle_config.decal_radius_px / tile_size_px * tile_size,
        )
        y = center.y + 0.002 * tile_size
        color = self._impact_decal_color(material, alpha)
        if material == SurfaceMaterial.DIRT:
            fade_radius = radius * (1.0 + 0.25 * progress)
            raylib.draw_cube(
                raylib.Vector3(center.x, y, center.z),
                fade_radius * 1.7,
                0.004 * tile_size,
                fade_radius * 0.55,
                color,
            )
            return
        if material == SurfaceMaterial.WOOD:
            raylib.draw_line_3d(
                raylib.Vector3(center.x - radius * 0.8, y, center.z - radius * 0.2),
                raylib.Vector3(center.x + radius * 0.7, y, center.z + radius * 0.25),
                color,
            )
            raylib.draw_line_3d(
                raylib.Vector3(center.x - radius * 0.2, y, center.z + radius * 0.55),
                raylib.Vector3(center.x + radius * 0.25, y, center.z - radius * 0.5),
                color,
            )
            return
        raylib.draw_line_3d(
            raylib.Vector3(center.x - radius, y, center.z),
            raylib.Vector3(center.x + radius * 0.85, y, center.z),
            color,
        )
        raylib.draw_line_3d(
            raylib.Vector3(center.x, y, center.z - radius * 0.8),
            raylib.Vector3(center.x, y, center.z + radius * 0.9),
            color,
        )
        if material in {SurfaceMaterial.STONE, SurfaceMaterial.EXPLOSIVE_METAL}:
            raylib.draw_line_3d(
                raylib.Vector3(center.x - radius * 0.55, y, center.z + radius * 0.45),
                raylib.Vector3(center.x + radius * 0.35, y, center.z - radius * 0.3),
                color,
            )

    def _draw_impact_particles_3d(
        self,
        *,
        center: object,
        material: SurfaceMaterial,
        particle_config: object,
        progress: float,
        alpha: int,
    ) -> None:
        """Draw configured 3D impact particles without sphere/ring markers."""
        raylib = self._raylib
        tile_size = self._config.render3d.tile_size
        tile_size_px = self._runtime_map.tile_size_px
        distance = (
            particle_config.spread_distance_px
            * particle_config.burst_intensity
            / tile_size_px
            * tile_size
            * (0.25 + progress * 0.75)
        )
        size = max(
            0.025 * tile_size,
            self._impact_particle_size(particle_config, progress) / tile_size_px * tile_size,
        )
        color = self._impact_color(material, alpha)
        for index, (offset_x, offset_y) in enumerate(
            self._particle_offsets(material, particle_config.particle_count),
        ):
            particle_center = raylib.Vector3(
                center.x + offset_x * distance,
                center.y + size * (0.5 + 0.1 * (index % 3)),
                center.z + offset_y * distance,
            )
            if material in {
                SurfaceMaterial.METAL,
                SurfaceMaterial.EXPLOSIVE_METAL,
                SurfaceMaterial.EXPLOSION,
                SurfaceMaterial.WOOD,
            }:
                raylib.draw_line_3d(
                    center,
                    particle_center,
                    color,
                )
            else:
                raylib.draw_cube(particle_center, size, size * 0.4, size, color)

    def _impact_color(self, material: SurfaceMaterial | str, alpha: int = 255) -> object:
        """Return a material-aware 3D impact core color."""
        normalized = self._normalize_surface_material(material)
        if normalized == SurfaceMaterial.STONE:
            return self._raylib.Color(200, 200, 190, alpha)
        if normalized == SurfaceMaterial.WOOD:
            return self._raylib.Color(160, 104, 52, alpha)
        if normalized == SurfaceMaterial.METAL:
            return self._raylib.Color(255, 218, 92, alpha)
        if normalized == SurfaceMaterial.EXPLOSIVE_METAL:
            return self._raylib.Color(255, 128, 52, alpha)
        if normalized == SurfaceMaterial.EXPLOSION:
            return self._raylib.Color(255, 76, 28, alpha)
        if normalized == SurfaceMaterial.FOLIAGE:
            return self._raylib.Color(92, 184, 72, alpha)
        if normalized == SurfaceMaterial.DIRT:
            return self._raylib.Color(128, 94, 62, alpha)
        return self._raylib.Color(255, 220, 160, alpha)


    def _impact_decal_color(self, material: SurfaceMaterial | str, alpha: int = 255) -> object:
        """Return a dark material-aware impact decal color."""
        normalized = self._normalize_surface_material(material)
        if normalized == SurfaceMaterial.WOOD:
            return self._raylib.Color(82, 48, 28, alpha)
        if normalized == SurfaceMaterial.DIRT:
            return self._raylib.Color(78, 58, 42, max(0, alpha - 35))
        if normalized in {SurfaceMaterial.METAL, SurfaceMaterial.EXPLOSIVE_METAL}:
            return self._raylib.Color(24, 22, 20, alpha)
        if normalized == SurfaceMaterial.EXPLOSION:
            return self._raylib.Color(92, 36, 20, alpha)
        return self._raylib.Color(46, 42, 36, alpha)

    def _impact_particle_config(self, material: SurfaceMaterial) -> object:
        """Return configured impact particles for one material."""
        return self._config.projectile_impacts.material_effects.get(
            material.value,
            self._config.projectile_impacts.material_effects["default"],
        )

    @staticmethod
    def _impact_particle_size(particle_config: object, progress: float) -> float:
        """Return current configured impact particle size."""
        return max(
            particle_config.particle_size_min_px,
            particle_config.particle_size_max_px
            - (particle_config.particle_size_max_px - particle_config.particle_size_min_px)
            * min(1.0, progress),
        )

    @staticmethod
    def _particle_offsets(
        material: SurfaceMaterial,
        particle_count: int,
    ) -> tuple[tuple[float, float], ...]:
        """Return deterministic unit directions for 3D impact particles."""
        count = max(1, particle_count)
        material_phase = {
            SurfaceMaterial.METAL: 0.08,
            SurfaceMaterial.EXPLOSIVE_METAL: 0.0,
            SurfaceMaterial.WOOD: 0.19,
            SurfaceMaterial.FOLIAGE: 0.31,
            SurfaceMaterial.DIRT: 0.43,
            SurfaceMaterial.EXPLOSION: 0.0,
            SurfaceMaterial.STONE: 0.12,
        }.get(material, 0.25)
        offsets: list[tuple[float, float]] = []
        golden_angle = math.pi * (3.0 - math.sqrt(5.0))
        for index in range(count):
            angle = material_phase * math.tau + golden_angle * index
            radius_scale = 0.72 + 0.28 * ((index * 37) % 11) / 10.0
            offsets.append((math.cos(angle) * radius_scale, math.sin(angle) * radius_scale))
        return tuple(offsets)

    def _impact_ring_color(self, material: SurfaceMaterial | str) -> object:
        """Return a material-aware 3D impact ring color."""
        normalized = self._normalize_surface_material(material)
        if normalized == SurfaceMaterial.METAL:
            return self._raylib.GOLD
        if normalized in {SurfaceMaterial.EXPLOSIVE_METAL, SurfaceMaterial.EXPLOSION}:
            return self._raylib.RED
        if normalized == SurfaceMaterial.FOLIAGE:
            return self._raylib.LIME
        if normalized == SurfaceMaterial.STONE:
            return self._raylib.GRAY
        return self._impact_color(normalized)

    @staticmethod
    def _impact_radius_scale(material: SurfaceMaterial | str, progress: float) -> float:
        """Return a material-aware impact radius scale."""
        try:
            normalized = SurfaceMaterial(material)
        except ValueError:
            normalized = SurfaceMaterial.DEFAULT
        if normalized == SurfaceMaterial.FOLIAGE:
            return 0.75 + progress * 0.2
        if normalized == SurfaceMaterial.EXPLOSIVE_METAL:
            return 1.15 + progress * 0.5
        if normalized == SurfaceMaterial.EXPLOSION:
            return 0.85 + progress * 0.9
        return 1.0 + progress * 0.35

    @staticmethod
    def _normalize_surface_material(material: SurfaceMaterial | str) -> SurfaceMaterial:
        """Return a known surface material for renderer fallback."""
        try:
            return SurfaceMaterial(material)
        except ValueError:
            return SurfaceMaterial.DEFAULT

    def _draw_aim_line(
        self,
        player_position: WorldCoord,
        facing_x: float,
        facing_y: float,
    ) -> None:
        """Draw the current 3D aim line from the player marker.

        Args:
            player_position: Current player world position in pixels.
            facing_x: Current facing X direction.
            facing_y: Current facing Y direction.
        """
        projectile_config = self._config.render3d.projectiles
        if not projectile_config.draw_aim_line:
            return
        raylib = self._raylib
        render_config = self._config.render3d
        tile_size = render_config.tile_size
        height_scale = render_config.height_scale
        tile_size_px = self._runtime_map.tile_size_px
        start = raylib.Vector3(
            player_position.x / tile_size_px * tile_size,
            projectile_config.projectile_height_tiles * height_scale,
            player_position.y / tile_size_px * tile_size,
        )
        end = raylib.Vector3(
            start.x + facing_x * projectile_config.aim_line_length_tiles * tile_size,
            start.y,
            start.z + facing_y * projectile_config.aim_line_length_tiles * tile_size,
        )
        raylib.draw_line_3d(start, end, raylib.GOLD)

    def _view_radius_px_squared(self) -> float:
        """Return squared 3D view radius in world pixels."""
        radius_px = self._config.render3d.view_radius_tiles * self._runtime_map.tile_size_px
        return radius_px * radius_px

    def _draw_player_marker(
        self,
        player_position: WorldCoord,
        facing_x: float,
        facing_y: float,
    ) -> None:
        """Draw the player marker and facing direction.

        Args:
            player_position: Current continuous player world position in pixels.
            facing_x: Current facing X direction.
            facing_y: Current facing Y direction.
        """
        raylib = self._raylib
        tile_size = self._config.render3d.tile_size
        height_scale = self._config.render3d.height_scale
        tile_size_px = self._runtime_map.tile_size_px
        center = raylib.Vector3(
            player_position.x / tile_size_px * tile_size,
            0.7 * height_scale,
            player_position.y / tile_size_px * tile_size,
        )
        raylib.draw_sphere(
            raylib.Vector3(center.x, center.y + 0.1 * height_scale, center.z),
            tile_size * 0.34,
            raylib.YELLOW,
        )
        raylib.draw_cylinder(
            raylib.Vector3(center.x, center.y - 0.35 * height_scale, center.z),
            tile_size * 0.26,
            tile_size * 0.22,
            0.75 * height_scale,
            16,
            raylib.GOLD,
        )
        direction_end = raylib.Vector3(
            center.x + facing_x * tile_size * 1.4,
            center.y + 0.3 * height_scale,
            center.z + facing_y * tile_size * 1.4,
        )
        raylib.draw_line_3d(center, direction_end, raylib.ORANGE)
        raylib.draw_sphere(direction_end, tile_size * 0.18, raylib.ORANGE)

    def _enemy_marker_color(self, enemy: EnemyState) -> object:
        """Return the current enemy body color, including hit flash feedback."""
        raylib = self._raylib
        if self._is_enemy_hit_flashing(enemy):
            return raylib.ORANGE
        if enemy.awareness_state == "engaged":
            return raylib.RED
        if enemy.awareness_state in {"searching", "returning"} or enemy.alerted:
            return raylib.ORANGE
        return raylib.MAROON

    def _enemy_state_color(self, enemy: EnemyState) -> object:
        """Return a high-readability color for enemy awareness indicators."""
        raylib = self._raylib
        if enemy.awareness_state == "engaged":
            return raylib.RED
        if enemy.awareness_state == "searching":
            return raylib.ORANGE
        if enemy.awareness_state == "returning":
            return raylib.GOLD
        if enemy.alerted:
            return raylib.ORANGE
        return raylib.DARKPURPLE

    def _is_enemy_hit_flashing(self, enemy: EnemyState) -> bool:
        """Return whether an enemy is inside the configured 3D hit flash window."""
        if enemy.last_hit_age_seconds is None:
            return False
        return (
            enemy.last_hit_age_seconds
            <= self._config.render3d.combat_visuals.enemy_hit_flash_seconds
        )

    @staticmethod
    def _age_progress(age_seconds: float, lifetime_seconds: float) -> float:
        """Return normalized marker age clamped to the 0..1 range."""
        if lifetime_seconds <= 0.0:
            return 1.0
        return max(0.0, min(1.0, age_seconds / lifetime_seconds))

    def _tile_color(self, symbol: str) -> object:
        """Return a simple debug color for a map tile symbol.

        Args:
            symbol: Source tile symbol.

        Returns:
            Raylib color object.
        """
        raylib = self._raylib
        return {
            "#": raylib.GRAY,
            "T": raylib.DARKBROWN,
            "b": raylib.LIME,
            "w": raylib.BLUE,
            ".": raylib.BEIGE,
            "R": raylib.LIGHTGRAY,
            "S": raylib.YELLOW,
            "G": raylib.GOLD,
        }.get(symbol, raylib.GREEN)

    def _set_mouse_capture(self, enabled: bool) -> None:
        """Capture or release the OS cursor for 3D mouse-look controls."""
        if self._mouse_capture_active == enabled:
            return
        if enabled:
            disable_cursor = getattr(self._raylib, "disable_cursor", None)
            if callable(disable_cursor):
                disable_cursor()
                self._mouse_capture_active = True
            return
        enable_cursor = getattr(self._raylib, "enable_cursor", None)
        if callable(enable_cursor):
            enable_cursor()
        self._mouse_capture_active = False

    def _configure_raylib_logging(self) -> None:
        """Reduce raylib logging noise before opening the 3D experiment window."""
        configure_raylib_logging(self._raylib)


    def _resolve_mouse_button(self, button_name: str) -> int:
        """Resolve a raylib mouse button constant by name."""
        return self._input.mouse_button(button_name)

    def _resolve_key(self, key_name: str) -> int:
        """Resolve a raylib key constant by name."""
        return self._input.key(key_name)

    def _resolve_player_keys(
        self,
        configured_key_names: tuple[str, ...],
        fallback_key_names: tuple[str, ...],
    ) -> tuple[int, ...]:
        """Resolve configured movement keys plus 3D experiment fallbacks."""
        key_names = configured_key_names + fallback_key_names
        return self._input.keys(key_names)

    def _is_any_key_down(self, keys: tuple[int, ...]) -> bool:
        """Return whether any key in a tuple is held down."""
        return is_any_key_down(self._raylib, keys)
