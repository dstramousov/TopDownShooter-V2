"""Shared gameplay runtime helpers."""
