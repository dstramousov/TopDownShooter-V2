"""Combat runtime systems."""
